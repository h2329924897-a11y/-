package com.ecommerce.order.service;

import com.ecommerce.order.common.PageResult;
import com.ecommerce.order.dto.CreateOrderDTO;
import com.ecommerce.order.dto.OrderQueryDTO;
import com.ecommerce.order.dto.UpdateOrderDTO;
import com.ecommerce.order.dto.UpdateStatusDTO;
import com.ecommerce.order.entity.Order;

/**
 * 订单服务接口
 * 定义订单模块的全部业务操作
 */
public interface OrderService {

    /**
     * 分页查询订单列表
     * @param queryDTO 查询条件
     * @return 分页结果
     */
    PageResult<Order> pageQuery(OrderQueryDTO queryDTO);

    /**
     * 查询订单详情（含订单项）
     * @param orderId 订单ID
     * @return 订单详情
     */
    Order getDetail(Integer orderId);

    /**
     * 创建订单（含订单项）
     * @param dto 创建订单请求
     * @return 创建的订单
     */
    Order create(CreateOrderDTO dto);

    /**
     * 更新订单信息（收货信息、备注等）
     * @param dto 更新请求
     * @return 更新后的订单
     */
    Order update(UpdateOrderDTO dto);

    /**
     * 更新订单状态
     * @param dto 状态更新请求
     * @return 更新后的订单
     */
    Order updateStatus(UpdateStatusDTO dto);

    /**
     * 删除订单（级联删除订单项）
     * @param orderId 订单ID
     */
    void delete(Integer orderId);
}

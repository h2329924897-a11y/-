package com.ecommerce.order.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

/**
 * 订单查询请求 DTO
 */
@Data
public class OrderQueryDTO {

    /** 用户ID（可选筛选） */
    private Integer userId;

    /** 订单状态（可选筛选） */
    private String status;

    /** 搜索关键词（订单号或商品名） */
    private String keyword;

    /** 页码（默认1） */
    @Min(value = 1, message = "页码必须大于0")
    private Integer page = 1;

    /** 每页条数（默认10，最大50） */
    @Min(value = 1, message = "每页条数至少为1")
    @Max(value = 50, message = "每页条数不能超过50")
    private Integer pageSize = 10;
}

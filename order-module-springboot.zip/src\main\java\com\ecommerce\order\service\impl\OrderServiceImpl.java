package com.ecommerce.order.service.impl;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.RandomUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ecommerce.order.common.PageResult;
import com.ecommerce.order.config.BusinessException;
import com.ecommerce.order.dto.*;
import com.ecommerce.order.entity.Order;
import com.ecommerce.order.entity.OrderItem;
import com.ecommerce.order.mapper.OrderItemMapper;
import com.ecommerce.order.mapper.OrderMapper;
import com.ecommerce.order.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

/**
 * 订单服务实现类
 * 使用 @Transactional 保证数据一致性
 */
@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderMapper orderMapper;

    @Autowired
    private OrderItemMapper orderItemMapper;

    // ==================== 查询操作 ====================

    /**
     * 分页查询订单列表
     * 支持按用户ID、状态、关键词（订单号/商品名）筛选
     */
    @Override
    public PageResult<Order> pageQuery(OrderQueryDTO queryDTO) {
        // 构建 MyBatis Plus 分页对象
        Page<Order> page = new Page<>(queryDTO.getPage(), queryDTO.getPageSize());

        // 执行自定义分页查询（联表查询用户名 + 子查询统计商品数）
        IPage<Order> result = orderMapper.selectOrderPage(
                page,
                queryDTO.getUserId(),
                queryDTO.getStatus(),
                queryDTO.getKeyword()
        );

        // 封装统一分页结果
        return new PageResult<>(
                result.getRecords(),
                result.getTotal(),
                result.getCurrent(),
                result.getSize()
        );
    }

    /**
     * 查询订单详情（含订单项明细）
     */
    @Override
    public Order getDetail(Integer orderId) {
        // 1. 查询订单主体
        Order order = orderMapper.selectById(orderId);
        if (order == null) {
            throw new BusinessException(404, "订单不存在");
        }

        // 2. 查询订单项列表并设置到订单对象
        List<OrderItem> items = orderItemMapper.selectByOrderId(orderId);
        // 注意：Order 实体中没有 items 字段，如需返回 items，
        // 需要在 Controller 层额外处理或使用 VO 对象。
        // 此处通过设置一个额外的非数据库字段来传递（示例中通过订单对象传递）

        return order;
    }

    // ==================== 新增操作 ====================

    /**
     * 创建订单（含订单项）
     * 事务保证：订单和订单项要么全部成功，要么全部回滚
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Order create(CreateOrderDTO dto) {
        // 1. 构建订单实体
        Order order = new Order();
        order.setOrderNo(generateOrderNo());          // 生成订单编号
        order.setUserId(dto.getUserId());
        order.setTotalAmount(dto.getTotalAmount());
        order.setStatus("pending");                    // 初始状态：待支付
        order.setReceiverName(dto.getReceiverName());
        order.setReceiverPhone(dto.getReceiverPhone());
        order.setReceiverAddress(dto.getReceiverAddress());
        order.setPaymentMethod(dto.getPaymentMethod());
        order.setRemark(dto.getRemark());
        order.setCreatedAt(LocalDateTime.now());
        order.setUpdatedAt(LocalDateTime.now());

        // 2. 保存订单
        int rows = orderMapper.insert(order);
        if (rows <= 0) {
            throw new BusinessException("创建订单失败");
        }

        // 3. 保存订单项（批量插入）
        if (dto.getItems() != null && !dto.getItems().isEmpty()) {
            // 计算实际总金额（以订单项小计为准，防止前端篡改金额）
            BigDecimal actualTotal = BigDecimal.ZERO;
            for (OrderItemDTO itemDTO : dto.getItems()) {
                OrderItem item = new OrderItem();
                item.setOrderId(order.getId());
                item.setProductId(itemDTO.getProductId());
                item.setProductName(itemDTO.getProductName());
                item.setProductPrice(itemDTO.getProductPrice());
                item.setQuantity(itemDTO.getQuantity());
                item.setSubtotal(itemDTO.getProductPrice().multiply(new BigDecimal(itemDTO.getQuantity())));
                orderItemMapper.insert(item);

                actualTotal = actualTotal.add(item.getSubtotal());
            }

            // 如果实际金额与传入金额不符，以实际计算为准更新订单
            if (actualTotal.compareTo(dto.getTotalAmount()) != 0) {
                order.setTotalAmount(actualTotal);
                orderMapper.updateById(order);
            }
        }

        return orderMapper.selectById(order.getId());
    }

    // ==================== 修改操作 ====================

    /**
     * 更新订单信息
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Order update(UpdateOrderDTO dto) {
        // 1. 查询订单是否存在
        Order order = orderMapper.selectById(dto.getId());
        if (order == null) {
            throw new BusinessException(404, "订单不存在");
        }

        // 2. 只更新非空字段
        if (dto.getReceiverName() != null) {
            order.setReceiverName(dto.getReceiverName());
        }
        if (dto.getReceiverPhone() != null) {
            order.setReceiverPhone(dto.getReceiverPhone());
        }
        if (dto.getReceiverAddress() != null) {
            order.setReceiverAddress(dto.getReceiverAddress());
        }
        if (dto.getPaymentMethod() != null) {
            order.setPaymentMethod(dto.getPaymentMethod());
        }
        if (dto.getRemark() != null) {
            order.setRemark(dto.getRemark());
        }
        order.setUpdatedAt(LocalDateTime.now());

        // 3. 执行更新
        orderMapper.updateById(order);

        return orderMapper.selectById(order.getId());
    }

    /**
     * 更新订单状态
     * 支持状态流转控制
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Order updateStatus(UpdateStatusDTO dto) {
        // 1. 查询订单
        Order order = orderMapper.selectById(dto.getId());
        if (order == null) {
            throw new BusinessException(404, "订单不存在");
        }

        // 2. 状态流转校验
        String currentStatus = order.getStatus();
        String targetStatus = dto.getStatus();

        // 已取消的订单不能修改状态
        if ("cancelled".equals(currentStatus)) {
            throw new BusinessException("已取消的订单无法修改状态");
        }
        // 已完成的订单不能回退
        if ("delivered".equals(currentStatus) && !"delivered".equals(targetStatus)) {
            throw new BusinessException("已完成的订单无法回退状态");
        }
        // 不能设置为相同状态
        if (currentStatus.equals(targetStatus)) {
            throw new BusinessException("订单已是该状态，无需重复操作");
        }

        // 3. 更新状态
        order.setStatus(targetStatus);
        order.setUpdatedAt(LocalDateTime.now());
        orderMapper.updateById(order);

        return orderMapper.selectById(order.getId());
    }

    // ==================== 删除操作 ====================

    /**
     * 删除订单（级联删除订单项）
     * 仅允许删除 pending 或 cancelled 状态的订单
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void delete(Integer orderId) {
        // 1. 查询订单
        Order order = orderMapper.selectById(orderId);
        if (order == null) {
            throw new BusinessException(404, "订单不存在");
        }

        // 2. 只允许删除待支付或已取消的订单
        if (!"pending".equals(order.getStatus()) && !"cancelled".equals(order.getStatus())) {
            throw new BusinessException("只能删除待支付或已取消的订单");
        }

        // 3. 先删除订单项，再删除订单（级联删除）
        orderItemMapper.deleteByOrderId(orderId);
        orderMapper.deleteById(orderId);
    }

    // ==================== 工具方法 ====================

    /**
     * 生成订单编号
     * 格式: ORD + yyyyMMddHHmmss + 4位随机数
     */
    private String generateOrderNo() {
        String dateStr = DateUtil.format(new Date(), "yyyyMMddHHmmss");
        String randomStr = RandomUtil.randomNumbers(4);
        return "ORD" + dateStr + randomStr;
    }
}

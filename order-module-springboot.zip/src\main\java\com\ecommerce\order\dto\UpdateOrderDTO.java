package com.ecommerce.order.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

/**
 * 更新订单请求 DTO
 */
@Data
public class UpdateOrderDTO {

    /** 订单ID（路径参数，此处用于校验） */
    @NotNull(message = "订单ID不能为空")
    @Min(value = 1, message = "订单ID必须大于0")
    private Integer id;

    /** 收货人姓名 */
    @Size(max = 50, message = "收货人姓名最多50个字符")
    private String receiverName;

    /** 收货人电话 */
    @Pattern(regexp = "^1[3-9]\\d{9}$", message = "手机号格式不正确")
    private String receiverPhone;

    /** 收货地址 */
    @Size(max = 500, message = "收货地址最多500个字符")
    private String receiverAddress;

    /** 支付方式 */
    private String paymentMethod;

    /** 订单备注 */
    @Size(max = 500, message = "备注最多500个字符")
    private String remark;
}

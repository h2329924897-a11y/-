package com.ecommerce.order;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 电商订单模块 - SpringBoot 启动类
 */
@SpringBootApplication
@MapperScan("com.ecommerce.order.mapper")
public class OrderApplication {

    public static void main(String[] args) {
        SpringApplication.run(OrderApplication.class, args);
        System.out.println("========================================");
        System.out.println("  电商订单模块启动成功！");
        System.out.println("  API 地址: http://localhost:8080");
        System.out.println("  Knife4j 文档: http://localhost:8080/doc.html");
        System.out.println("========================================");
    }
}

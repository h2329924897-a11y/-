package com.ecommerce.order.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.math.BigDecimal;

/**
 * 创建订单请求 DTO
 */
@Data
public class CreateOrderDTO {

    /** 用户ID */
    @NotNull(message = "用户ID不能为空")
    @Min(value = 1, message = "用户ID必须大于0")
    private Integer userId;

    /** 订单总金额 */
    @NotNull(message = "订单总金额不能为空")
    @DecimalMin(value = "0.01", message = "订单金额必须大于0")
    private BigDecimal totalAmount;

    /** 收货人姓名 */
    @NotBlank(message = "收货人姓名不能为空")
    @Size(max = 50, message = "收货人姓名最多50个字符")
    private String receiverName;

    /** 收货人电话 */
    @NotBlank(message = "收货人电话不能为空")
    @Pattern(regexp = "^1[3-9]\\d{9}$", message = "手机号格式不正确")
    private String receiverPhone;

    /** 收货地址 */
    @NotBlank(message = "收货地址不能为空")
    @Size(max = 500, message = "收货地址最多500个字符")
    private String receiverAddress;

    /** 支付方式 */
    private String paymentMethod = "online";

    /** 订单备注 */
    @Size(max = 500, message = "备注最多500个字符")
    private String remark;

    /** 订单项列表 */
    @NotEmpty(message = "订单项不能为空")
    private java.util.List<OrderItemDTO> items;
}

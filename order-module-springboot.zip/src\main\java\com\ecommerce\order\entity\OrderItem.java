package com.ecommerce.order.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.math.BigDecimal;

/**
 * 订单项实体类
 * 对应数据库 order_items 表
 */
@Data
@TableName("order_items")
public class OrderItem {

    /** 订单项ID（自增） */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /** 订单ID */
    private Integer orderId;

    /** 商品ID */
    private Integer productId;

    /** 商品名称（下单时快照） */
    private String productName;

    /** 商品单价（下单时快照） */
    private BigDecimal productPrice;

    /** 购买数量 */
    private Integer quantity;

    /** 小计金额 */
    private BigDecimal subtotal;
}

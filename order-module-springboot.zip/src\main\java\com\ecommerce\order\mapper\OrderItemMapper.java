package com.ecommerce.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ecommerce.order.entity.OrderItem;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 订单项 Mapper 接口
 */
public interface OrderItemMapper extends BaseMapper<OrderItem> {

    /**
     * 根据订单ID查询所有订单项
     */
    @Select("SELECT * FROM order_items WHERE order_id = #{orderId}")
    List<OrderItem> selectByOrderId(@Param("orderId") Integer orderId);

    /**
     * 根据订单ID删除所有订单项
     */
    @Delete("DELETE FROM order_items WHERE order_id = #{orderId}")
    int deleteByOrderId(@Param("orderId") Integer orderId);

    /**
     * 批量插入订单项
     */
    @Select("<script>" +
            "INSERT INTO order_items (order_id, product_id, product_name, product_price, quantity, subtotal) VALUES " +
            "<foreach collection='items' item='item' separator=','>" +
            "(#{orderId}, #{item.productId}, #{item.productName}, #{item.productPrice}, #{item.quantity}, " +
            " #{item.productPrice} * #{item.quantity})" +
            "</foreach>" +
            "</script>")
    int batchInsert(@Param("orderId") Integer orderId,
                    @Param("items") List<OrderItem> items);
}

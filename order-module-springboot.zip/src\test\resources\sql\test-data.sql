-- 测试数据
INSERT INTO users (id, username, password, nickname, email, phone, role) VALUES
(1, 'admin', 'encoded_password', '管理员', 'admin@shop.com', '13800000000', 'admin'),
(2, 'user1', 'encoded_password', '张三',   'zhangsan@qq.com', '13800000001', 'user'),
(3, 'user2', 'encoded_password', '李四',   'lisi@qq.com', '13800000002', 'user');

INSERT INTO products (id, name, category, price, original_price, description, sales, stock) VALUES
(1, 'iPhone 15 Pro Max',      '手机数码', 8999.00,  9999.00,  'Apple旗舰手机',    1520, 100),
(2, 'MacBook Pro 14英寸 M3',  '电脑办公', 14999.00, 16999.00, 'Apple笔记本',      890,  50),
(3, 'Sony WH-1000XM5 耳机',   '影音娱乐', 2299.00,  2999.00,  '索尼降噪耳机',     2340, 200);

INSERT INTO orders (id, order_no, user_id, total_amount, status, receiver_name, receiver_phone, receiver_address, payment_method) VALUES
(1, 'ORD20240325001', 2, 11298.00, 'paid',      '张三', '13800000001', '广西南宁市西乡塘区大学东路188号', 'online'),
(2, 'ORD20240324001', 2, 2299.00,  'shipped',   '张三', '13800000001', '广西南宁市西乡塘区大学东路188号', 'online'),
(3, 'ORD20240320001', 2, 99.00,    'delivered', '张三', '13800000001', '广西南宁市西乡塘区大学东路188号', 'online'),
(4, 'ORD20240325002', 3, 14999.00, 'pending',   '李四', '13800000002', '广西南宁市青秀区民族大道100号',   'online'),
(5, 'ORD20240323001', 3, 4299.00,  'cancelled', '李四', '13800000002', '广西南宁市青秀区民族大道100号',   'online');

INSERT INTO order_items (id, order_id, product_id, product_name, product_price, quantity, subtotal) VALUES
(1, 1, 1, 'iPhone 15 Pro Max',    8999.00,  1, 8999.00),
(2, 1, 3, 'Sony WH-1000XM5 耳机', 2299.00,  1, 2299.00),
(3, 2, 3, 'Sony WH-1000XM5 耳机', 2299.00,  1, 2299.00),
(4, 3, 2, 'MacBook Pro 14英寸 M3', 14999.00, 1, 14999.00),
(5, 4, 2, 'MacBook Pro 14英寸 M3', 14999.00, 1, 14999.00);

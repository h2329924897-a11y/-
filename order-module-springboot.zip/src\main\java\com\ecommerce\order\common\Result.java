package com.ecommerce.order.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 统一响应结果封装
 *
 * @param <T> 数据类型
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Result<T> {

    /** 状态码 */
    private int code;

    /** 提示信息 */
    private String message;

    /** 响应数据 */
    private T data;

    // ==================== 静态工厂方法 ====================

    /** 成功（无数据） */
    public static <T> Result<T> ok() {
        return new Result<T>(200, "操作成功", null);
    }

    /** 成功（带数据） */
    public static <T> Result<T> ok(T data) {
        return new Result<T>(200, "操作成功", data);
    }

    /** 成功（自定义消息 + 数据） */
    public static <T> Result<T> ok(String message, T data) {
        return new Result<T>(200, message, data);
    }

    /** 失败 */
    public static <T> Result<T> fail(int code, String message) {
        return new Result<T>(code, message, null);
    }

    /** 失败（默认400） */
    public static <T> Result<T> fail(String message) {
        return new Result<T>(400, message, null);
    }
}

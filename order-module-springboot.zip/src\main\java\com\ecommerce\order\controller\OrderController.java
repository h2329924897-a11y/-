package com.ecommerce.order.controller;

import com.ecommerce.order.common.PageResult;
import com.ecommerce.order.common.Result;
import com.ecommerce.order.dto.*;
import com.ecommerce.order.entity.Order;
import com.ecommerce.order.mapper.OrderItemMapper;
import com.ecommerce.order.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * 订单管理 Controller
 *
 * RESTful API 设计：
 * GET    /api/orders          - 分页查询
 * GET    /api/orders/{id}     - 查询详情
 * POST   /api/orders          - 创建订单
 * PUT    /api/orders/{id}     - 更新订单
 * PATCH  /api/orders/{id}/status - 更新状态
 * DELETE /api/orders/{id}     - 删除订单
 */
@RestController
@RequestMapping("/api/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private OrderItemMapper orderItemMapper;

    /**
     * 分页查询订单列表
     *
     * 请求示例:
     * GET /api/orders?page=1&pageSize=10&status=paid&keyword=iPhone
     */
    @GetMapping
    public Result<PageResult<Order>> list(@Valid OrderQueryDTO queryDTO) {
        PageResult<Order> pageResult = orderService.pageQuery(queryDTO);
        return Result.ok("查询成功", pageResult);
    }

    /**
     * 查询订单详情（含订单项）
     *
     * 请求示例:
     * GET /api/orders/1
     */
    @GetMapping("/{id}")
    public Result<Map<String, Object>> detail(@PathVariable Integer id) {
        Order order = orderService.getDetail(id);

        // 组装详情（订单主体 + 订单项列表）
        Map<String, Object> result = new HashMap<>();
        result.put("order", order);
        result.put("items", orderItemMapper.selectByOrderId(id));

        return Result.ok("查询成功", result);
    }

    /**
     * 创建订单
     *
     * 请求示例:
     * POST /api/orders
     * Body: { "userId": 2, "totalAmount": 11298.00, "receiverName": "张三", ... }
     */
    @PostMapping
    public Result<Order> create(@Valid @RequestBody CreateOrderDTO dto) {
        Order order = orderService.create(dto);
        return Result.ok("订单创建成功", order);
    }

    /**
     * 更新订单信息
     *
     * 请求示例:
     * PUT /api/orders/1
     * Body: { "receiverName": "张三丰", "receiverPhone": "13900000001" }
     */
    @PutMapping("/{id}")
    public Result<Order> update(@PathVariable Integer id,
                                 @Valid @RequestBody UpdateOrderDTO dto) {
        dto.setId(id);
        Order order = orderService.update(dto);
        return Result.ok("订单更新成功", order);
    }

    /**
     * 更新订单状态
     *
     * 请求示例:
     * PATCH /api/orders/1/status
     * Body: { "status": "paid" }
     */
    @PatchMapping("/{id}/status")
    public Result<Order> updateStatus(@PathVariable Integer id,
                                       @Valid @RequestBody UpdateStatusDTO dto) {
        dto.setId(id);
        Order order = orderService.updateStatus(dto);
        return Result.ok("订单状态更新成功", order);
    }

    /**
     * 删除订单（级联删除订单项）
     *
     * 请求示例:
     * DELETE /api/orders/1
     */
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Integer id) {
        orderService.delete(id);
        return Result.ok();
    }
}

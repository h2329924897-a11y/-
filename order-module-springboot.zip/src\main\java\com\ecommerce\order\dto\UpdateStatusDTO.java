package com.ecommerce.order.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

/**
 * 更新订单状态请求 DTO
 */
@Data
public class UpdateStatusDTO {

    /** 订单ID */
    private Integer id;

    /** 目标状态 */
    @NotBlank(message = "状态不能为空")
    @Pattern(regexp = "^(pending|paid|shipped|delivered|cancelled)$",
             message = "状态值无效，可选: pending, paid, shipped, delivered, cancelled")
    private String status;
}

package com.ecommerce.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ecommerce.order.entity.Order;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * 订单 Mapper 接口
 * 继承 MyBatis Plus BaseMapper，自动拥有基础 CRUD 方法
 */
public interface OrderMapper extends BaseMapper<Order> {

    /**
     * 分页查询订单列表（含用户名、商品数量）
     *
     * @param page    分页对象
     * @param userId  用户ID（可选）
     * @param status  订单状态（可选）
     * @param keyword 搜索关键词（可选）
     * @return 分页结果
     */
    @Select("<script>" +
            "SELECT o.*, u.username, u.nickname, " +
            "       (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = o.id) AS item_count " +
            "FROM orders o " +
            "LEFT JOIN users u ON o.user_id = u.id " +
            "<where>" +
            "  <if test='userId != null'>AND o.user_id = #{userId}</if>" +
            "  <if test='status != null and status != \"\"'>AND o.status = #{status}</if>" +
            "  <if test='keyword != null and keyword != \"\"'>" +
            "    AND (o.order_no LIKE CONCAT('%', #{keyword}, '%') " +
            "         OR o.id IN (SELECT DISTINCT oi2.order_id FROM order_items oi2 " +
            "                     WHERE oi2.product_name LIKE CONCAT('%', #{keyword}, '%')))" +
            "  </if>" +
            "</where>" +
            "ORDER BY o.created_at DESC" +
            "</script>")
    IPage<Order> selectOrderPage(Page<Order> page,
                                  @Param("userId") Integer userId,
                                  @Param("status") String status,
                                  @Param("keyword") String keyword);

    /**
     * 查询订单详情（含订单项）
     * MyBatis Plus 默认的 selectById 只能查单表，
     * 此处需要在 Service 层额外查询 order_items 后组装
     */
}

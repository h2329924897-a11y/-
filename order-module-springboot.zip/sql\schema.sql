-- ===================================================
-- 电商平台订单模块 - 表结构 SQL
-- 数据库: ecommerce_platform
-- 说明: 基于原有 Node.js 项目表结构，适配 SpringBoot + MyBatis Plus
-- ===================================================

-- 创建数据库（如不存在）
CREATE DATABASE IF NOT EXISTS ecommerce_platform
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE ecommerce_platform;

-- ===================================================
-- 1. 用户表（基础依赖表）
-- ===================================================
CREATE TABLE IF NOT EXISTS users (
    id          INT AUTO_INCREMENT PRIMARY KEY COMMENT '用户ID',
    username    VARCHAR(50)  NOT NULL UNIQUE COMMENT '用户名',
    password    VARCHAR(255) NOT NULL COMMENT '密码(bcrypt哈希)',
    nickname    VARCHAR(50)  DEFAULT '' COMMENT '昵称',
    email       VARCHAR(100) DEFAULT '' COMMENT '邮箱',
    phone       VARCHAR(20)  DEFAULT '' COMMENT '手机号',
    role        ENUM('user','admin') DEFAULT 'user' COMMENT '角色',
    status      TINYINT      DEFAULT 1 COMMENT '状态: 1-启用 0-禁用',
    created_at  DATETIME     DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at  DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_username (username),
    INDEX idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- ===================================================
-- 2. 商品表（基础依赖表）
-- ===================================================
CREATE TABLE IF NOT EXISTS products (
    id             INT AUTO_INCREMENT PRIMARY KEY COMMENT '商品ID',
    name           VARCHAR(200)   NOT NULL COMMENT '商品名称',
    category       VARCHAR(50)    DEFAULT '' COMMENT '商品分类',
    price          DECIMAL(10,2)  NOT NULL COMMENT '售价',
    original_price DECIMAL(10,2)  DEFAULT NULL COMMENT '原价',
    image_url      VARCHAR(500)   DEFAULT '' COMMENT '商品图片URL',
    description    TEXT           COMMENT '商品描述',
    sales          INT            DEFAULT 0 COMMENT '销量',
    stock          INT            DEFAULT 0 COMMENT '库存',
    status         TINYINT        DEFAULT 1 COMMENT '状态: 1-上架 0-下架',
    created_at     DATETIME       DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at     DATETIME       DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_category (category),
    INDEX idx_price (price),
    INDEX idx_sales (sales)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品表';

-- ===================================================
-- 3. 订单表（核心表）
-- ===================================================
CREATE TABLE IF NOT EXISTS orders (
    id               INT AUTO_INCREMENT PRIMARY KEY COMMENT '订单主键ID',
    order_no         VARCHAR(32)    NOT NULL UNIQUE COMMENT '订单编号',
    user_id          INT            NOT NULL COMMENT '用户ID',
    total_amount     DECIMAL(10,2)  NOT NULL COMMENT '订单总金额',
    status           ENUM('pending','paid','shipped','delivered','cancelled')
                                    DEFAULT 'pending' COMMENT '订单状态',
    receiver_name    VARCHAR(50)    DEFAULT '' COMMENT '收货人姓名',
    receiver_phone   VARCHAR(20)    DEFAULT '' COMMENT '收货人电话',
    receiver_address VARCHAR(500)   DEFAULT '' COMMENT '收货地址',
    payment_method   VARCHAR(20)    DEFAULT 'online' COMMENT '支付方式',
    remark           VARCHAR(500)   DEFAULT '' COMMENT '订单备注',
    created_at       DATETIME       DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at       DATETIME       DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_user_id (user_id),
    INDEX idx_order_no (order_no),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表';

-- ===================================================
-- 4. 订单项表（订单商品明细）
-- ===================================================
CREATE TABLE IF NOT EXISTS order_items (
    id            INT AUTO_INCREMENT PRIMARY KEY COMMENT '订单项ID',
    order_id      INT            NOT NULL COMMENT '订单ID',
    product_id    INT            NOT NULL COMMENT '商品ID',
    product_name  VARCHAR(200)   NOT NULL COMMENT '商品名称（快照）',
    product_price DECIMAL(10,2)  NOT NULL COMMENT '商品单价（快照）',
    quantity      INT            NOT NULL DEFAULT 1 COMMENT '购买数量',
    subtotal      DECIMAL(10,2)  NOT NULL COMMENT '小计金额',
    INDEX idx_order_id (order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单项表';

-- ===================================================
-- 5. 测试数据
-- ===================================================

-- 用户数据
INSERT IGNORE INTO users (id, username, password, nickname, email, phone, role) VALUES
(1, 'admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5Eh', '系统管理员', 'admin@shop.com', '13800000000', 'admin'),
(2, 'user1', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5Eh', '张三',      'zhangsan@qq.com', '13800000001', 'user'),
(3, 'user2', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5Eh', '李四',      'lisi@qq.com',     '13800000002', 'user');

-- 商品数据
INSERT IGNORE INTO products (id, name, category, price, original_price, description, sales, stock) VALUES
(1, 'iPhone 15 Pro Max 256GB',       '手机数码', 8999.00,  9999.00,  'Apple iPhone 15 Pro Max，256GB存储，钛金属设计，A17 Pro芯片',                         1520, 100),
(2, 'MacBook Pro 14英寸 M3',         '电脑办公', 14999.00, 16999.00, 'Apple MacBook Pro，M3芯片，14英寸Liquid Retina XDR显示屏',                             890,  50),
(3, 'Sony WH-1000XM5 头戴式耳机',    '影音娱乐', 2299.00,  2999.00,  '索尼旗舰降噪耳机，30小时续航，Hi-Res音频',                                               2340, 200),
(4, 'Nike Air Jordan 1 复古篮球鞋',  '运动户外', 1299.00,  1499.00,  'Nike经典复刻篮球鞋，Air Jordan 1 Retro High OG',                                       4560, 300),
(5, '三只松鼠坚果大礼包 2kg',        '食品生鲜', 99.00,    139.00,   '混合坚果大礼包，含夏威夷果、腰果、巴旦木等',                                             8900, 500),
(6, '华为MatePad Pro 13.2英寸',      '手机数码', 4299.00,  4999.00,  '华为旗舰平板，13.2英寸OLED屏幕，HarmonyOS系统',                                          670,  80),
(7, '戴森V15 Detect 无绳吸尘器',     '家用电器', 4990.00,  5490.00,  '戴森无线吸尘器，激光探测微尘，LCD显示屏',                                               1230, 60),
(8, 'LEGO 乐高 兰博基尼 Sián FKP 37','玩具乐器', 2999.00,  3499.00,  '乐高机械组旗舰超跑，3696颗粒，1:8比例',                                                 340,  30);

-- 订单数据
INSERT IGNORE INTO orders (id, order_no, user_id, total_amount, status, receiver_name, receiver_phone, receiver_address, payment_method) VALUES
(1, 'ORD20240325001', 2, 11298.00, 'paid',      '张三', '13800000001', '广西南宁市西乡塘区大学东路188号 广西民族大学', 'online'),
(2, 'ORD20240324001', 2, 2299.00,  'shipped',   '张三', '13800000001', '广西南宁市西乡塘区大学东路188号 广西民族大学', 'online'),
(3, 'ORD20240320001', 2, 99.00,    'delivered', '张三', '13800000001', '广西南宁市西乡塘区大学东路188号 广西民族大学', 'online'),
(4, 'ORD20240325002', 3, 14999.00, 'pending',   '李四', '13800000002', '广西南宁市青秀区民族大道100号',              'online'),
(5, 'ORD20240323001', 3, 4299.00,  'cancelled', '李四', '13800000002', '广西南宁市青秀区民族大道100号',              'online');

-- 订单项数据
INSERT IGNORE INTO order_items (id, order_id, product_id, product_name, product_price, quantity, subtotal) VALUES
(1, 1, 1, 'iPhone 15 Pro Max 256GB',    8999.00,  1, 8999.00),
(2, 1, 3, 'Sony WH-1000XM5 头戴式耳机', 2299.00,  1, 2299.00),
(3, 2, 3, 'Sony WH-1000XM5 头戴式耳机', 2299.00,  1, 2299.00),
(4, 3, 5, '三只松鼠坚果大礼包 2kg',     99.00,    1, 99.00),
(5, 4, 2, 'MacBook Pro 14英寸 M3',      14999.00, 1, 14999.00),
(6, 5, 6, '华为MatePad Pro 13.2英寸',   4299.00,  1, 4299.00);

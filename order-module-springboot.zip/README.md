# 电商订单模块 (Order Module)

基于 **Spring Boot 3.2** + **MyBatis Plus 3.5** 的电商订单管理后端模块。

## 技术栈

- **Java 17**
- **Spring Boot 3.2.5**
- **MyBatis Plus 3.5.6**
- **MySQL** (生产) / **H2** (测试)
- **Lombok** / **Hutool**

## 项目结构

```
src/
├── main/java/com/ecommerce/order/
│   ├── common/          # 通用类（统一响应、分页、异常码）
│   ├── config/          # 配置类（MyBatis Plus、全局异常处理、跨域）
│   ├── controller/      # 控制器层
│   ├── dto/             # 数据传输对象（请求/响应）
│   ├── entity/          # 数据库实体
│   ├── enums/           # 枚举类
│   ├── exception/       # 自定义异常
│   ├── mapper/          # MyBatis Plus Mapper
│   └── service/         # 服务层接口与实现
└── test/                # 测试
```

## API 接口

| 方法   | 路径                     | 说明           |
|--------|--------------------------|----------------|
| GET    | /api/orders              | 分页查询订单   |
| GET    | /api/orders/{id}         | 查询订单详情   |
| POST   | /api/orders              | 创建订单       |
| PUT    | /api/orders/{id}         | 更新订单信息   |
| PATCH  | /api/orders/{id}/status  | 更新订单状态   |
| DELETE | /api/orders/{id}         | 删除订单       |

## 快速开始

### 环境要求

- JDK 17+
- MySQL 8.0+
- Maven 3.6+

### 配置数据库

编辑 `src/main/resources/application.yml` 中的数据库连接信息：

```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/ecommerce
    username: root
    password: your_password
```

### 运行

```bash
# 编译运行
mvn spring-boot:run

# 打包
mvn clean package -DskipTests
java -jar target/order-module-1.0.0.jar
```

### 测试

```bash
# 运行全部测试（使用 H2 内存数据库，无需 MySQL）
mvn test
```

测试覆盖：29 个测试用例，涵盖 Service 层和 Controller 层全接口。

-- ===================================================
-- 测试环境 H2 数据库建表语句
-- 兼容 MySQL 语法
-- ===================================================

CREATE TABLE IF NOT EXISTS users (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    username    VARCHAR(50)  NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,
    nickname    VARCHAR(50)  DEFAULT '',
    email       VARCHAR(100) DEFAULT '',
    phone       VARCHAR(20)  DEFAULT '',
    role        VARCHAR(10)  DEFAULT 'user',
    status      TINYINT      DEFAULT 1,
    created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    name           VARCHAR(200)   NOT NULL,
    category       VARCHAR(50)    DEFAULT '',
    price          DECIMAL(10,2)  NOT NULL,
    original_price DECIMAL(10,2)  DEFAULT NULL,
    image_url      VARCHAR(500)   DEFAULT '',
    description    VARCHAR(2000),
    sales          INT            DEFAULT 0,
    stock          INT            DEFAULT 0,
    status         TINYINT        DEFAULT 1,
    created_at     TIMESTAMP      DEFAULT CURRENT_TIMESTAMP,
    updated_at     TIMESTAMP      DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orders (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    order_no         VARCHAR(32)    NOT NULL UNIQUE,
    user_id          INT            NOT NULL,
    total_amount     DECIMAL(10,2)  NOT NULL,
    status           VARCHAR(20)    DEFAULT 'pending',
    receiver_name    VARCHAR(50)    DEFAULT '',
    receiver_phone   VARCHAR(20)    DEFAULT '',
    receiver_address VARCHAR(500)   DEFAULT '',
    payment_method   VARCHAR(20)    DEFAULT 'online',
    remark           VARCHAR(500)   DEFAULT '',
    created_at       TIMESTAMP      DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP      DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS order_items (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    order_id      INT            NOT NULL,
    product_id    INT            NOT NULL,
    product_name  VARCHAR(200)   NOT NULL,
    product_price DECIMAL(10,2)  NOT NULL,
    quantity      INT            NOT NULL DEFAULT 1,
    subtotal      DECIMAL(10,2)  NOT NULL
);

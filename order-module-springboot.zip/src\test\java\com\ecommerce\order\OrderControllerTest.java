package com.ecommerce.order;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.http.*;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 订单模块 Controller 层集成测试
 *
 * 使用 TestRestTemplate 发起真实 HTTP 请求，测试完整链路。
 * 通过 TestConfiguration 注入支持 PATCH 的 RestTemplate。
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
class OrderControllerTest {

    @DynamicPropertySource
    static void configureDatabase(DynamicPropertyRegistry registry) {
        // 使用独立数据库名，避免与其他测试类冲突
        registry.add("spring.datasource.url", () ->
            "jdbc:h2:mem:ordercontrollertest;MODE=MySQL;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE");
    }

    /**
     * 注入支持 PATCH 方法的 RestTemplate
     * HttpComponentsClientHttpRequestFactory 支持所有 HTTP 方法
     */
    @TestConfiguration
    static class RestTemplateConfig {
        @Bean
        @Primary
        public TestRestTemplate testRestTemplate() {
            TestRestTemplate template = new TestRestTemplate();
            template.getRestTemplate().setRequestFactory(new HttpComponentsClientHttpRequestFactory());
            return template;
        }
    }

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    private String baseUrl;

    @BeforeEach
    void setUp() {
        baseUrl = "http://localhost:" + port + "/api/orders";
    }

    // ==================== GET 查询接口 ====================

    @Test
    @org.junit.jupiter.api.Order(1)
    @DisplayName("GET /api/orders - 分页查询（无筛选）")
    void testList_NoFilter() {
        ResponseEntity<Map> response = restTemplate.getForEntity(
                baseUrl + "?page=1&pageSize=10", Map.class);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        Map<String, Object> body = response.getBody();
        assertNotNull(body);
        assertEquals(200, body.get("code"));
        Map<String, Object> data = (Map<String, Object>) body.get("data");
        assertEquals(5, data.get("total"));
        assertEquals(1, data.get("totalPages"));

        System.out.println("✓ GET 分页查询（无筛选）通过: total=" + data.get("total"));
    }

    @Test
    @org.junit.jupiter.api.Order(2)
    @DisplayName("GET /api/orders - 按状态筛选")
    void testList_FilterByStatus() {
        ResponseEntity<Map> response = restTemplate.getForEntity(
                baseUrl + "?status=paid", Map.class);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        Map<String, Object> body = response.getBody();
        assertEquals(200, body.get("code"));
        Map<String, Object> data = (Map<String, Object>) body.get("data");
        assertEquals(1, data.get("total"));

        System.out.println("✓ GET 按状态筛选通过: status=paid, total=" + data.get("total"));
    }

    @Test
    @org.junit.jupiter.api.Order(3)
    @DisplayName("GET /api/orders - 小分页测试")
    void testList_PageSize2() {
        ResponseEntity<Map> response = restTemplate.getForEntity(
                baseUrl + "?page=1&pageSize=2", Map.class);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        Map<String, Object> body = response.getBody();
        assertEquals(200, body.get("code"));
        Map<String, Object> data = (Map<String, Object>) body.get("data");
        assertEquals(5, data.get("total"));
        assertEquals(3, data.get("totalPages"));

        System.out.println("✓ GET 小分页测试通过: pageSize=2, totalPages=" + data.get("totalPages"));
    }

    @Test
    @org.junit.jupiter.api.Order(4)
    @DisplayName("GET /api/orders - 参数校验失败（page=0）")
    void testList_InvalidParam() {
        ResponseEntity<Map> response = restTemplate.getForEntity(
                baseUrl + "?page=0", Map.class);

        assertTrue(response.getStatusCode().is4xxClientError());
        Map<String, Object> body = response.getBody();
        assertNotNull(body);

        System.out.println("✓ GET 参数校验失败正确拦截: page=0");
    }

    @Test
    @org.junit.jupiter.api.Order(5)
    @DisplayName("GET /api/orders/{id} - 查询详情")
    void testDetail() {
        ResponseEntity<Map> response = restTemplate.getForEntity(
                baseUrl + "/1", Map.class);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        Map<String, Object> body = response.getBody();
        assertEquals(200, body.get("code"));
        Map<String, Object> data = (Map<String, Object>) body.get("data");
        assertNotNull(data);
        assertNotNull(data.get("order"));
        assertNotNull(data.get("items"));

        System.out.println("✓ GET 查询详情通过: id=1");
    }

    @Test
    @org.junit.jupiter.api.Order(6)
    @DisplayName("GET /api/orders/{id} - 查询不存在的订单")
    void testDetail_NotFound() {
        ResponseEntity<Map> response = restTemplate.getForEntity(
                baseUrl + "/9999", Map.class);

        assertTrue(response.getStatusCode().is4xxClientError());
        Map<String, Object> body = response.getBody();
        assertEquals(404, body.get("code"));

        System.out.println("✓ GET 查询不存在订单正确返回404");
    }

    // ==================== POST 创建接口 ====================

    @Test
    @org.junit.jupiter.api.Order(7)
    @DisplayName("POST /api/orders - 创建订单")
    void testCreate_Success() {
        Map<String, Object> requestBody = Map.of(
                "userId", 2,
                "totalAmount", 9098.00,
                "receiverName", "王五",
                "receiverPhone", "13900000003",
                "receiverAddress", "北京市朝阳区",
                "paymentMethod", "online",
                "items", List.of(
                        Map.of(
                                "productId", 1,
                                "productName", "iPhone 15 Pro Max",
                                "productPrice", 8999.00,
                                "quantity", 1
                        ),
                        Map.of(
                                "productId", 5,
                                "productName", "坚果大礼包",
                                "productPrice", 99.00,
                                "quantity", 1
                        )
                )
        );

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);

        ResponseEntity<Map> response = restTemplate.postForEntity(
                baseUrl, request, Map.class);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        Map<String, Object> body = response.getBody();
        assertEquals(200, body.get("code"));
        Map<String, Object> data = (Map<String, Object>) body.get("data");
        assertEquals("pending", data.get("status"));
        assertNotNull(data.get("orderNo"));

        System.out.println("✓ POST 创建订单通过: orderNo=" + data.get("orderNo") + ", status=" + data.get("status"));
    }

    @Test
    @org.junit.jupiter.api.Order(8)
    @DisplayName("POST /api/orders - 参数校验失败（缺少必填字段）")
    void testCreate_ValidationFailed() {
        Map<String, Object> requestBody = Map.of();  // 空对象

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);

        ResponseEntity<Map> response = restTemplate.postForEntity(
                baseUrl, request, Map.class);

        assertTrue(response.getStatusCode().is4xxClientError());

        System.out.println("✓ POST 参数校验失败正确拦截");
    }

    // ==================== PUT 更新接口 ====================

    @Test
    @org.junit.jupiter.api.Order(9)
    @DisplayName("PUT /api/orders/{id} - 更新订单信息")
    void testUpdate_Success() {
        // id 字段是 @NotNull 的，必须传入
        Map<String, Object> requestBody = Map.of(
                "id", 1,
                "receiverName", "张三丰",
                "receiverPhone", "13900000001",
                "remark", "通过接口更新"
        );

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);

        ResponseEntity<Map> response = restTemplate.exchange(
                baseUrl + "/1",
                HttpMethod.PUT,
                request,
                Map.class);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        Map<String, Object> body = response.getBody();
        assertEquals(200, body.get("code"));
        Map<String, Object> data = (Map<String, Object>) body.get("data");
        assertEquals("张三丰", data.get("receiverName"));

        System.out.println("✓ PUT 更新订单通过: receiverName=" + data.get("receiverName"));
    }

    // ==================== PATCH 状态更新接口 ====================

    @Test
    @org.junit.jupiter.api.Order(10)
    @DisplayName("PATCH /api/orders/{id}/status - 更新状态 pending→paid")
    void testUpdateStatus_Success() {
        Map<String, Object> requestBody = Map.of("status", "paid");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);

        ResponseEntity<Map> response = restTemplate.exchange(
                baseUrl + "/4/status",
                HttpMethod.PATCH,
                request,
                Map.class);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        Map<String, Object> body = response.getBody();
        assertEquals(200, body.get("code"));
        Map<String, Object> data = (Map<String, Object>) body.get("data");
        assertEquals("paid", data.get("status"));

        System.out.println("✓ PATCH 状态更新通过: pending → paid");
    }

    @Test
    @org.junit.jupiter.api.Order(11)
    @DisplayName("PATCH /api/orders/{id}/status - 无效状态值")
    void testUpdateStatus_InvalidStatus() {
        Map<String, Object> requestBody = Map.of("status", "invalid_status");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Map<String, Object>> request = new HttpEntity<>(requestBody, headers);

        ResponseEntity<Map> response = restTemplate.exchange(
                baseUrl + "/1/status",
                HttpMethod.PATCH,
                request,
                Map.class);

        assertTrue(response.getStatusCode().is4xxClientError());

        System.out.println("✓ PATCH 无效状态值正确拦截");
    }

    // ==================== DELETE 删除接口 ====================

    @Test
    @org.junit.jupiter.api.Order(12)
    @DisplayName("DELETE /api/orders/{id} - 不允许删除 shipped 状态订单")
    void testDelete_NotAllowed() {
        ResponseEntity<Map> response = restTemplate.exchange(
                baseUrl + "/2",
                HttpMethod.DELETE,
                null,
                Map.class);

        assertTrue(response.getStatusCode().is4xxClientError());

        System.out.println("✓ DELETE shipped 状态订单正确拦截");
    }

    // ==================== 测试总结 ====================

    @AfterAll
    static void printSummary() {
        System.out.println("\n========================================");
        System.out.println("  Controller 层集成测试全部完成");
        System.out.println("  测试方式: TestRestTemplate（真实 HTTP 请求）");
        System.out.println("  测试接口: GET查询 | POST创建 | PUT更新 | PATCH状态 | DELETE删除");
        System.out.println("  覆盖场景: 正常流程 + 异常校验 + 边界条件");
        System.out.println("  共 12 个测试方法");
        System.out.println("========================================");
    }
}

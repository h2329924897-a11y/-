package com.ecommerce.order.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.math.BigDecimal;

/**
 * 订单项 DTO（创建订单时使用）
 */
@Data
public class OrderItemDTO {

    /** 商品ID */
    @NotNull(message = "商品ID不能为空")
    @Min(value = 1, message = "商品ID必须大于0")
    private Integer productId;

    /** 商品名称 */
    @NotBlank(message = "商品名称不能为空")
    private String productName;

    /** 商品单价 */
    @NotNull(message = "商品单价不能为空")
    @DecimalMin(value = "0.01", message = "商品单价必须大于0")
    private BigDecimal productPrice;

    /** 购买数量 */
    @NotNull(message = "购买数量不能为空")
    @Min(value = 1, message = "购买数量至少为1")
    @Max(value = 999, message = "购买数量不能超过999")
    private Integer quantity;
}

package com.ecommerce.order;

import com.ecommerce.order.dto.*;
import com.ecommerce.order.entity.Order;
import com.ecommerce.order.entity.OrderItem;
import com.ecommerce.order.mapper.OrderItemMapper;
import com.ecommerce.order.mapper.OrderMapper;
import com.ecommerce.order.service.OrderService;
import com.ecommerce.order.common.PageResult;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 订单模块 Service 层单元测试
 *
 * 使用 H2 内存数据库，不依赖外部 MySQL
 * 每个测试方法独立运行，互不影响
 *
 * 注意：此测试使用纯 Spring 上下文（不启用 Mockito），
 * 以兼容 Java 24 环境。
 */
@SpringBootTest
@ActiveProfiles("test")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
class OrderServiceTest {

    @DynamicPropertySource
    static void configureDatabase(DynamicPropertyRegistry registry) {
        // 使用独立数据库名，避免与其他测试类冲突
        registry.add("spring.datasource.url", () ->
            "jdbc:h2:mem:orderservicetest;MODE=MySQL;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE");
    }

    @Autowired
    private OrderService orderService;

    @Autowired
    private OrderMapper orderMapper;

    @Autowired
    private OrderItemMapper orderItemMapper;

    // ==================== 测试1: 分页查询 ====================

    @Test
    @org.junit.jupiter.api.Order(1)
    @DisplayName("分页查询订单列表 - 无筛选条件")
    void testPageQuery_NoFilter() {
        OrderQueryDTO queryDTO = new OrderQueryDTO();
        queryDTO.setPage(1);
        queryDTO.setPageSize(10);

        PageResult<Order> result = orderService.pageQuery(queryDTO);

        assertNotNull(result);
        assertEquals(5, result.getTotal());       // 测试数据共5条
        assertEquals(5, result.getList().size());  // 每页10条，5条全在一页
        assertEquals(1, result.getTotalPages());   // 总页数为1

        System.out.println("✓ 分页查询（无筛选）通过: total=" + result.getTotal() + ", pages=" + result.getTotalPages());
    }

    @Test
    @org.junit.jupiter.api.Order(2)
    @DisplayName("分页查询订单列表 - 按状态筛选")
    void testPageQuery_FilterByStatus() {
        OrderQueryDTO queryDTO = new OrderQueryDTO();
        queryDTO.setStatus("paid");
        queryDTO.setPage(1);
        queryDTO.setPageSize(10);

        PageResult<Order> result = orderService.pageQuery(queryDTO);

        assertNotNull(result);
        assertEquals(1, result.getTotal());
        assertEquals("paid", result.getList().get(0).getStatus());

        System.out.println("✓ 按状态筛选通过: status=paid, count=" + result.getTotal());
    }

    @Test
    @org.junit.jupiter.api.Order(3)
    @DisplayName("分页查询订单列表 - 按用户ID筛选")
    void testPageQuery_FilterByUserId() {
        OrderQueryDTO queryDTO = new OrderQueryDTO();
        queryDTO.setUserId(2);  // user1 有3笔订单
        queryDTO.setPage(1);
        queryDTO.setPageSize(10);

        PageResult<Order> result = orderService.pageQuery(queryDTO);

        assertNotNull(result);
        assertEquals(3, result.getTotal());
        result.getList().forEach(order -> assertEquals(2, order.getUserId()));

        System.out.println("✓ 按用户ID筛选通过: userId=2, count=" + result.getTotal());
    }

    @Test
    @org.junit.jupiter.api.Order(4)
    @DisplayName("分页查询订单列表 - 按关键词搜索")
    void testPageQuery_ByKeyword() {
        OrderQueryDTO queryDTO = new OrderQueryDTO();
        queryDTO.setKeyword("iPhone");
        queryDTO.setPage(1);
        queryDTO.setPageSize(10);

        PageResult<Order> result = orderService.pageQuery(queryDTO);

        assertNotNull(result);
        assertTrue(result.getTotal() >= 1);

        System.out.println("✓ 按关键词搜索通过: keyword=iPhone, count=" + result.getTotal());
    }

    @Test
    @org.junit.jupiter.api.Order(5)
    @DisplayName("分页查询 - 小分页测试")
    void testPageQuery_SmallPageSize() {
        OrderQueryDTO queryDTO = new OrderQueryDTO();
        queryDTO.setPage(1);
        queryDTO.setPageSize(2);  // 每页2条，共5条 → 3页

        PageResult<Order> result = orderService.pageQuery(queryDTO);

        assertNotNull(result);
        assertEquals(5, result.getTotal());
        assertEquals(2, result.getList().size());
        assertEquals(3, result.getTotalPages());

        System.out.println("✓ 小分页测试通过: pageSize=2, totalPages=" + result.getTotalPages());
    }

    // ==================== 测试2: 查询详情 ====================

    @Test
    @org.junit.jupiter.api.Order(6)
    @DisplayName("查询订单详情 - 存在的订单")
    void testGetDetail_Exists() {
        Order order = orderService.getDetail(1);

        assertNotNull(order);
        assertEquals("ORD20240325001", order.getOrderNo());
        assertEquals("paid", order.getStatus());
        assertEquals(new BigDecimal("11298.00"), order.getTotalAmount());

        System.out.println("✓ 查询详情通过: orderNo=" + order.getOrderNo() + ", status=" + order.getStatus());
    }

    @Test
    @org.junit.jupiter.api.Order(7)
    @DisplayName("查询订单详情 - 不存在的订单（期望抛出异常）")
    void testGetDetail_NotExists() {
        assertThrows(Exception.class, () -> {
            orderService.getDetail(9999);
        });

        System.out.println("✓ 查询不存在订单正确抛出异常");
    }

    // ==================== 测试3: 创建订单 ====================

    @Test
    @org.junit.jupiter.api.Order(8)
    @DisplayName("创建订单 - 正常流程")
    void testCreateOrder_Success() {
        CreateOrderDTO dto = new CreateOrderDTO();
        dto.setUserId(2);
        dto.setTotalAmount(new BigDecimal("9298.00"));
        dto.setReceiverName("王五");
        dto.setReceiverPhone("13900000003");
        dto.setReceiverAddress("北京市朝阳区");
        dto.setPaymentMethod("online");
        dto.setRemark("测试创建订单");

        // 订单项
        List<OrderItemDTO> items = new ArrayList<>();
        OrderItemDTO item1 = new OrderItemDTO();
        item1.setProductId(1);
        item1.setProductName("iPhone 15 Pro Max");
        item1.setProductPrice(new BigDecimal("8999.00"));
        item1.setQuantity(1);
        items.add(item1);

        OrderItemDTO item2 = new OrderItemDTO();
        item2.setProductId(5);
        item2.setProductName("三只松鼠坚果大礼包");
        item2.setProductPrice(new BigDecimal("99.00"));
        item2.setQuantity(1);
        items.add(item2);

        dto.setItems(items);

        // 执行创建
        Order created = orderService.create(dto);

        // 验证
        assertNotNull(created);
        assertNotNull(created.getId());
        assertEquals("pending", created.getStatus());
        assertEquals("王五", created.getReceiverName());
        assertTrue(created.getOrderNo().startsWith("ORD"));

        // 验证订单项是否创建
        List<OrderItem> savedItems = orderItemMapper.selectByOrderId(created.getId());
        assertEquals(2, savedItems.size());

        // 验证实际金额以订单项计算为准
        assertEquals(new BigDecimal("9098.00"), created.getTotalAmount());

        System.out.println("✓ 创建订单成功，订单号: " + created.getOrderNo() + ", 金额: " + created.getTotalAmount());
    }

    // ==================== 测试4: 更新订单 ====================

    @Test
    @org.junit.jupiter.api.Order(9)
    @DisplayName("更新订单信息")
    void testUpdateOrder() {
        UpdateOrderDTO dto = new UpdateOrderDTO();
        dto.setId(1);
        dto.setReceiverName("张三丰");
        dto.setReceiverPhone("13900000001");
        dto.setRemark("测试更新备注");

        Order updated = orderService.update(dto);

        assertNotNull(updated);
        assertEquals("张三丰", updated.getReceiverName());
        assertEquals("13900000001", updated.getReceiverPhone());
        assertEquals("测试更新备注", updated.getRemark());

        System.out.println("✓ 更新订单成功: 收货人=" + updated.getReceiverName());
    }

    // ==================== 测试5: 更新订单状态 ====================

    @Test
    @org.junit.jupiter.api.Order(10)
    @DisplayName("更新订单状态 - pending → paid")
    void testUpdateStatus_PendingToPaid() {
        UpdateStatusDTO dto = new UpdateStatusDTO();
        dto.setId(4);  // pending 状态
        dto.setStatus("paid");

        Order updated = orderService.updateStatus(dto);

        assertNotNull(updated);
        assertEquals("paid", updated.getStatus());

        System.out.println("✓ 状态更新成功: pending → paid");
    }

    @Test
    @org.junit.jupiter.api.Order(11)
    @DisplayName("更新订单状态 - 已取消订单不允许修改")
    void testUpdateStatus_CancelledNotAllowed() {
        UpdateStatusDTO dto = new UpdateStatusDTO();
        dto.setId(5);  // cancelled 状态
        dto.setStatus("paid");

        assertThrows(Exception.class, () -> {
            orderService.updateStatus(dto);
        });

        System.out.println("✓ 已取消订单正确拦截状态修改");
    }

    @Test
    @org.junit.jupiter.api.Order(12)
    @DisplayName("更新订单状态 - 相同状态不允许")
    void testUpdateStatus_SameStatus() {
        UpdateStatusDTO dto = new UpdateStatusDTO();
        dto.setId(1);
        dto.setStatus("paid");  // 当前已是 paid

        assertThrows(Exception.class, () -> {
            orderService.updateStatus(dto);
        });

        System.out.println("✓ 相同状态正确拦截");
    }

    // ==================== 测试6: 删除订单 ====================

    @Test
    @org.junit.jupiter.api.Order(13)
    @DisplayName("删除订单 - cancelled 状态可删除")
    void testDelete_CancelledOrder() {
        // 测试数据中订单ID=5是 cancelled 状态
        assertDoesNotThrow(() -> orderService.delete(5));

        // 验证订单已删除
        assertNull(orderMapper.selectById(5));

        // 验证订单项级联删除
        List<OrderItem> itemsAfterDelete = orderItemMapper.selectByOrderId(5);
        assertTrue(itemsAfterDelete.isEmpty());

        System.out.println("✓ 订单及订单项级联删除成功");
    }

    @Test
    @org.junit.jupiter.api.Order(14)
    @DisplayName("删除订单 - shipped 状态不允许删除")
    void testDelete_ShippedNotAllowed() {
        assertThrows(Exception.class, () -> {
            orderService.delete(2);  // shipped 状态
        });

        System.out.println("✓ shipped 状态订单正确拦截删除");
    }

    // ==================== 测试7: Mapper 层直接测试 ====================

    @Test
    @org.junit.jupiter.api.Order(15)
    @DisplayName("Mapper - 基础 CRUD 方法")
    void testMapperBasicCRUD() {
        // selectById
        Order order = orderMapper.selectById(1);
        assertNotNull(order);
        assertEquals("ORD20240325001", order.getOrderNo());

        // selectList
        List<Order> orders = orderMapper.selectList(null);
        assertTrue(orders.size() >= 5);

        // selectCount
        Long count = orderMapper.selectCount(null);
        assertTrue(count >= 5);

        System.out.println("✓ Mapper 基础 CRUD 验证通过: count=" + count);
    }

    @Test
    @org.junit.jupiter.api.Order(16)
    @DisplayName("Mapper - 订单项查询")
    void testOrderItemMapper() {
        List<OrderItem> items = orderItemMapper.selectByOrderId(1);
        assertEquals(2, items.size());

        BigDecimal total = items.stream()
                .map(OrderItem::getSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        assertEquals(new BigDecimal("11298.00"), total);

        System.out.println("✓ 订单项查询验证通过，共" + items.size() + "项，总金额=" + total);
    }

    // ==================== 测试总结 ====================

    @AfterAll
    static void printSummary() {
        System.out.println("\n========================================");
        System.out.println("  订单模块 Service 层单元测试全部完成");
        System.out.println("  测试覆盖: 分页查询 | 详情查询 | 创建 | 更新 | 状态变更 | 删除");
        System.out.println("  数据库: H2 内存数据库（隔离测试）");
        System.out.println("  共 16 个测试方法");
        System.out.println("========================================");
    }
}

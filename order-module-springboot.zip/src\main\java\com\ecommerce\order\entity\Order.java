package com.ecommerce.order.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 订单实体类
 * 对应数据库 orders 表
 */
@Data
@TableName("orders")
public class Order {

    /** 订单主键ID（自增） */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /** 订单编号（唯一） */
    private String orderNo;

    /** 用户ID */
    private Integer userId;

    /** 订单总金额 */
    private BigDecimal totalAmount;

    /**
     * 订单状态
     * pending   - 待支付
     * paid      - 已支付
     * shipped   - 已发货
     * delivered - 已完成
     * cancelled - 已取消
     */
    private String status;

    /** 收货人姓名 */
    private String receiverName;

    /** 收货人电话 */
    private String receiverPhone;

    /** 收货地址 */
    private String receiverAddress;

    /** 支付方式 */
    private String paymentMethod;

    /** 订单备注 */
    private String remark;

    /** 创建时间 */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;

    /** 更新时间 */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updatedAt;

    // ========== 非数据库字段（用于联表查询展示） ==========

    /** 用户名（关联查询） */
    @TableField(exist = false)
    private String username;

    /** 用户昵称（关联查询） */
    @TableField(exist = false)
    private String nickname;

    /** 商品数量（聚合查询） */
    @TableField(exist = false)
    private Integer itemCount;
}

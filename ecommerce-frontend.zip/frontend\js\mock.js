/**
 * mock.js - Mock 数据服务
 *
 * 模拟后端 API，生成商品列表数据，支持分页和分类筛选。
 *
 * 核心规则：
 *   - 每访问一页发送一次请求（模拟真实分页查询）
 *   - 每次请求有 300~800ms 模拟网络延迟
 *   - 返回统一格式：{ code, message, data: { list, pagination } }
 *   - 支持分类筛选：电子产品、服装鞋包、家居生活、图书音像、运动户外
 */

(function (global) {
  'use strict';

  // ==================== 商品分类定义 ====================
  var CATEGORIES = [
    { id: 'electronics', name: '电子产品' },
    { id: 'clothing',   name: '服装鞋包' },
    { id: 'home',       name: '家居生活' },
    { id: 'books',      name: '图书音像' },
    { id: 'sports',     name: '运动户外' },
  ];

  // ==================== Mock 商品池 ====================
  // 为每个分类预生成 25 条商品，总共 125 条
  var PRODUCT_POOL = [];

  (function generateProductPool() {
    var productNames = {
      electronics: [
        '智能手机 Pro Max', '轻薄笔记本 Air', '无线蓝牙耳机', '智能手表 S10',
        '平板电脑 Pad Pro', '机械键盘 RGB', '4K 显示器 27寸', '移动电源 20000mAh',
        'Type-C 扩展坞', '无线鼠标 静音版', 'USB-C 充电器 65W', '手机云台稳定器',
        '智能音箱 AI版', '运动相机 4K', '电子书阅读器', '降噪耳机 头戴式',
        '路由器 WiFi6', '固态硬盘 1TB', '内存条 16GB', '显卡 RTX 4070',
        '游戏手柄 无线版', '摄像头 1080P', '打印机 激光', 'UPS 不间断电源', '网络交换机 8口',
      ],
      clothing: [
        '纯棉 T 恤 基础款', '牛仔裤 修身版', '运动鞋 缓震科技', '连帽卫衣 加绒',
        '休闲西装 单排扣', '羊绒大衣 双面呢', '马丁靴 真皮', '羽绒服 轻薄款',
        '针织开衫 V领', '阔腿裤 高腰', '帆布鞋 经典款', 'POLO衫 商务休闲',
        '风衣 中长款', '棒球帽 刺绣', '太阳镜 偏光', '皮带 头层牛皮',
        '衬衫 免烫款', '短裤 速干面料', '拖鞋 居家', '围巾 羊毛',
        '手套 触屏', '袜子 运动款 5双装', '双肩包 商务', '斜挎包 迷你', '钱包 短款',
      ],
      home: [
        '记忆棉枕头', '乳胶床垫 1.8m', '实木餐桌 4椅', '落地灯 北欧风',
        '收纳箱 大号 3件套', '空气炸锅 5L', '电热水壶 恒温', '扫地机器人 激光导航',
        '窗帘 遮光 定制', '地毯 客厅 2x3m', '餐具套装 24头', '刀具套装 7件',
        '挂钟 静音', '花洒 增压', '毛巾 纯棉 6条', '衣架 防滑 20个',
        '香薰机 超声波', '加湿器 卧室', '台灯 护眼 LED', '储物柜 塑料',
        '保鲜盒 玻璃 6件套', '垃圾桶 智能感应', '晾衣架 折叠', '浴室置物架', '鞋柜 翻斗',
      ],
      books: [
        'JavaScript 高级程序设计', '深入理解计算机系统', '算法导论 第四版',
        '设计模式 可复用面向对象', 'Python 编程 从入门到实践', '三体 全集',
        '活着', '百年孤独', '小王子 中英双语', '人类简史',
        '经济学原理', '影响力', '思考，快与慢', '原则',
        '刻意练习', '非暴力沟通', '自控力', '时间简史',
        '万历十五年', '乡土中国', '围城', '红楼梦',
        '解忧杂货店', '追风筝的人', '月亮与六便士',
      ],
      sports: [
        '跑步鞋 竞速款', '瑜伽垫 加厚防滑', '哑铃套装 20kg', '跳绳 轴承高速',
        '篮球 室内外通用', '羽毛球拍 碳素', '登山杖 伸缩', '泳镜 防雾',
        '骑行头盔 轻量', '护膝 运动防护', '运动水壶 750ml', '臂力器 40kg',
        '拉力绳 套装', '呼啦圈 可拆卸', '健腹轮 自动回弹', '泡沫轴 肌肉放松',
        '网球拍 初学者', '足球 5号', '乒乓球拍 双面反胶', '滑板 枫木',
        '运动腰包 防水', '速干毛巾 健身', '运动手套 半指', '平衡板 核心训练', '筋膜枪 深层按摩',
      ],
    };

    var basePrice = {
      electronics: [299, 599, 1299, 2499, 4999, 8999],
      clothing: [79, 159, 299, 499, 899, 1599],
      home: [49, 99, 199, 399, 699, 1299],
      books: [19, 29, 39, 59, 79, 99],
      sports: [39, 79, 149, 299, 499, 899],
    };

    Object.keys(productNames).forEach(function (catId) {
      var names = productNames[catId];
      var prices = basePrice[catId];

      for (var i = 0; i < names.length; i++) {
        var priceIdx = Math.floor(Math.random() * prices.length);
        PRODUCT_POOL.push({
          id: PRODUCT_POOL.length + 1,
          name: names[i],
          category_id: catId,
          price: prices[priceIdx] + Math.floor(Math.random() * prices[priceIdx] * 0.5),
          stock: 10 + Math.floor(Math.random() * 200),
          sales: Math.floor(Math.random() * 5000),
          image: null,
          description: names[i] + ' - 高品质商品，正品保障，售后无忧',
          created_at: '2026-0' + (1 + Math.floor(Math.random() * 6)) + '-' +
            String(1 + Math.floor(Math.random() * 28)).padStart(2, '0') + ' ' +
            String(8 + Math.floor(Math.random() * 14)).padStart(2, '0') + ':00:00',
        });
      }
    });
  })();

  // ==================== 模拟网络延迟 ====================
  function mockDelay() {
    var ms = 300 + Math.random() * 500; // 300~800ms
    return new Promise(function (resolve) {
      setTimeout(resolve, ms);
    });
  }

  // ==================== Mock API 实现 ====================

  var MockAPI = {
    /**
     * 商品列表查询（分页 + 分类筛选）
     *
     * @param {Object} params
     *   - page:     页码（默认 1）
     *   - pageSize: 每页条数（默认 12，最大 50）
     *   - category: 分类 ID（可选，如 'electronics'）
     *   - keyword:  关键词搜索（可选）
     *   - sortBy:   排序字段（price / sales / created_at）
     *   - sortOrder: 排序方向（ASC / DESC）
     *
     * @returns {Promise<{code, message, data: {list, pagination}}>}
     */
    getProductList: async function (params) {
      params = params || {};

      // 模拟网络延迟 —— 每次请求都产生延迟，体现"每页一次请求"
      await mockDelay();

      // 参数解析与校验
      var page = Math.max(1, parseInt(params.page) || 1);
      var pageSize = Math.min(50, Math.max(1, parseInt(params.pageSize) || 12));
      var category = params.category || '';
      var keyword = (params.keyword || '').trim().toLowerCase();
      var sortBy = params.sortBy || 'id';
      var sortOrder = (params.sortOrder || 'ASC').toUpperCase();

      // ---- 筛选 ----
      var filtered = PRODUCT_POOL.slice(); // 浅拷贝

      // 按分类筛选
      if (category) {
        filtered = filtered.filter(function (p) {
          return p.category_id === category;
        });
      }

      // 按关键词搜索
      if (keyword) {
        filtered = filtered.filter(function (p) {
          return p.name.toLowerCase().indexOf(keyword) !== -1 ||
                 p.description.toLowerCase().indexOf(keyword) !== -1;
        });
      }

      // ---- 排序 ----
      filtered.sort(function (a, b) {
        var valA = a[sortBy];
        var valB = b[sortBy];
        if (typeof valA === 'string') {
          return sortOrder === 'DESC'
            ? valB.localeCompare(valA)
            : valA.localeCompare(valB);
        }
        return sortOrder === 'DESC' ? valB - valA : valA - valB;
      });

      // ---- 分页 ----
      var total = filtered.length;
      var totalPages = Math.ceil(total / pageSize);
      var startIndex = (page - 1) * pageSize;
      var list = filtered.slice(startIndex, startIndex + pageSize);

      // 构造统一响应格式
      return {
        code: 200,
        message: '查询成功 (Mock)',
        data: {
          list: list,
          pagination: {
            page: page,
            pageSize: pageSize,
            total: total,
            totalPages: totalPages,
          },
        },
      };
    },

    /**
     * 获取所有分类列表
     */
    getCategories: async function () {
      await mockDelay();
      return {
        code: 200,
        message: '查询成功 (Mock)',
        data: CATEGORIES,
      };
    },

    /**
     * 商品详情
     */
    getProductDetail: async function (id) {
      await mockDelay();
      id = parseInt(id);
      for (var i = 0; i < PRODUCT_POOL.length; i++) {
        if (PRODUCT_POOL[i].id === id) {
          return {
            code: 200,
            message: '查询成功 (Mock)',
            data: PRODUCT_POOL[i],
          };
        }
      }
      return {
        code: 404,
        message: '商品不存在',
        data: null,
      };
    },
  };

  // ==================== 分类名称映射 ====================
  var CATEGORY_MAP = {};
  CATEGORIES.forEach(function (c) {
    CATEGORY_MAP[c.id] = c.name;
  });

  // ==================== 挂载到全局 ====================
  global.MockAPI = MockAPI;
  global.CATEGORIES = CATEGORIES;
  global.CATEGORY_MAP = CATEGORY_MAP;

})(window);

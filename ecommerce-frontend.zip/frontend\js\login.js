/**
 * 登录页面逻辑
 * 
 * 实现功能：
 * - 表单验证
 * - 调用登录 API
 * - Token 存储与状态管理
 * - 登录后跳转
 */

document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('loginForm');
  const usernameInput = document.getElementById('username');
  const passwordInput = document.getElementById('password');
  const loginBtn = document.getElementById('loginBtn');
  const btnText = document.getElementById('btnText');
  const btnSpinner = document.getElementById('btnSpinner');
  const errorMsg = document.getElementById('errorMsg');

  // 检查是否已登录
  const token = localStorage.getItem('token');
  if (token) {
    window.location.href = '/orders.html';
    return;
  }

  /**
   * 设置按钮加载状态
   */
  function setLoading(loading) {
    if (loading) {
      loginBtn.disabled = true;
      btnText.textContent = '登录中...';
      btnSpinner.style.display = 'inline-block';
    } else {
      loginBtn.disabled = false;
      btnText.textContent = '登 录';
      btnSpinner.style.display = 'none';
    }
  }

  /**
   * 显示错误信息
   */
  function showError(message) {
    errorMsg.textContent = message;
    errorMsg.classList.add('show');
  }

  /**
   * 隐藏错误信息
   */
  function hideError() {
    errorMsg.textContent = '';
    errorMsg.classList.remove('show');
  }

  /**
   * 表单验证
   */
  function validate(username, password) {
    if (!username.trim()) {
      showError('请输入用户名');
      return false;
    }
    if (!password.trim()) {
      showError('请输入密码');
      return false;
    }
    if (password.length < 4) {
      showError('密码长度不能少于4位');
      return false;
    }
    return true;
  }

  /**
   * 处理登录提交
   */
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    hideError();

    const username = usernameInput.value.trim();
    const password = passwordInput.value.trim();

    // 前端表单验证
    if (!validate(username, password)) return;

    setLoading(true);

    try {
      // 调用登录 API
      const response = await authAPI.login(username, password);

      if (response.code === 200) {
        // 登录成功，存储 Token 和用户信息
        localStorage.setItem('token', response.data.token);
        localStorage.setItem('user', JSON.stringify(response.data.user));

        showToast('登录成功，正在跳转...', 'success');

        // 延迟跳转，让用户看到提示
        setTimeout(() => {
          window.location.href = '/orders.html';
        }, 800);
      } else {
        showError(response.message || '登录失败');
      }
    } catch (error) {
      console.error('[登录] 错误:', error);
      showError(error.message || '登录失败，请稍后重试');
    } finally {
      setLoading(false);
    }
  });

  // 输入框变化时清除错误信息
  usernameInput.addEventListener('input', hideError);
  passwordInput.addEventListener('input', hideError);

  // 回车键切换焦点
  usernameInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      passwordInput.focus();
    }
  });
});

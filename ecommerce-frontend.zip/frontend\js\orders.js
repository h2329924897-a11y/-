/**
 * 订单列表页面逻辑
 * 
 * 实现功能：
 * - 订单列表展示（分页）
 * - 按状态筛选
 * - 按订单号/商品名搜索
 * - 订单详情弹窗
 * - Token 认证状态检查
 * - 退出登录
 */

document.addEventListener('DOMContentLoaded', () => {
  // ==================== 状态管理 ====================
  const state = {
    orders: [],
    pagination: {
      page: 1,
      pageSize: 10,
      total: 0,
      totalPages: 0
    },
    filters: {
      status: '',
      keyword: ''
    },
    currentUser: null
  };

  // ==================== DOM 元素引用 ====================
  const elements = {
    userName: document.getElementById('userName'),
    userRole: document.getElementById('userRole'),
    orderList: document.getElementById('orderList'),
    orderCount: document.getElementById('orderCount'),
    searchKeyword: document.getElementById('searchKeyword'),
    statusFilter: document.getElementById('statusFilter'),
    searchBtn: document.getElementById('searchBtn'),
    resetBtn: document.getElementById('resetBtn'),
    pagination: document.getElementById('pagination'),
    modalOverlay: document.getElementById('modalOverlay'),
    modalBody: document.getElementById('modalBody'),
    logoutBtn: document.getElementById('logoutBtn')
  };

  // ==================== 初始化 ====================

  function init() {
    // 检查登录状态
    const user = checkAuth();
    if (!user) return;

    state.currentUser = user;

    // 渲染用户信息
    renderUserInfo();

    // 加载订单列表
    loadOrders();

    // 绑定事件
    bindEvents();
  }

  /**
   * 渲染顶部用户信息
   */
  function renderUserInfo() {
    const user = state.currentUser;
    elements.userName.textContent = user.nickname || user.username;
    elements.userRole.textContent = user.role === 'admin' ? '管理员' : '普通用户';
    if (user.role === 'admin') {
      elements.userRole.classList.add('admin');
    }
  }

  /**
   * 绑定事件监听
   */
  function bindEvents() {
    // 搜索按钮
    elements.searchBtn.addEventListener('click', () => {
      state.filters.keyword = elements.searchKeyword.value.trim();
      state.filters.status = elements.statusFilter.value;
      state.pagination.page = 1;
      loadOrders();
    });

    // 重置按钮
    elements.resetBtn.addEventListener('click', () => {
      elements.searchKeyword.value = '';
      elements.statusFilter.value = '';
      state.filters = { status: '', keyword: '' };
      state.pagination.page = 1;
      loadOrders();
    });

    // 回车搜索
    elements.searchKeyword.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        elements.searchBtn.click();
      }
    });

    // 状态筛选变化时自动搜索
    elements.statusFilter.addEventListener('change', () => {
      state.filters.status = elements.statusFilter.value;
      state.pagination.page = 1;
      loadOrders();
    });

    // 退出登录
    elements.logoutBtn.addEventListener('click', () => {
      if (confirm('确定要退出登录吗？')) {
        logout();
      }
    });

    // 关闭弹窗（点击遮罩）
    elements.modalOverlay.addEventListener('click', (e) => {
      if (e.target === elements.modalOverlay) {
        closeModal();
      }
    });

    // ESC 关闭弹窗
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        closeModal();
      }
    });
  }

  // ==================== 数据加载 ====================

  /**
   * 加载订单列表
   */
  async function loadOrders() {
    try {
      // 显示加载状态
      elements.orderList.innerHTML = `
        <div class="loading">
          <div class="spinner-large"></div>
          <p>正在加载订单...</p>
        </div>
      `;
      elements.pagination.innerHTML = '';

      // 调用 API
      const response = await orderAPI.getList({
        page: state.pagination.page,
        pageSize: state.pagination.pageSize,
        status: state.filters.status,
        keyword: state.filters.keyword
      });

      if (response.code === 200) {
        state.orders = response.data.list;
        state.pagination = response.data.pagination;

        renderOrders();
        renderPagination();
      } else {
        showToast(response.message || '加载订单失败', 'error');
        renderEmpty();
      }
    } catch (error) {
      console.error('[订单加载] 错误:', error);
      showToast(error.message || '加载订单失败', 'error');
      renderEmpty();
    }
  }

  /**
   * 加载订单详情
   */
  async function loadOrderDetail(orderId) {
    try {
      // 显示加载状态
      elements.modalBody.innerHTML = `
        <div class="loading">
          <div class="spinner-large"></div>
          <p>正在加载订单详情...</p>
        </div>
      `;
      showModal();

      const response = await orderAPI.getDetail(orderId);

      if (response.code === 200) {
        renderOrderDetail(response.data);
      } else {
        elements.modalBody.innerHTML = `<p style="text-align:center;color:#ff4d4f;">${response.message || '加载失败'}</p>`;
      }
    } catch (error) {
      console.error('[订单详情] 错误:', error);
      elements.modalBody.innerHTML = `<p style="text-align:center;color:#ff4d4f;">${error.message || '加载失败'}</p>`;
    }
  }

  // ==================== 渲染函数 ====================

  /**
   * 渲染订单列表
   */
  function renderOrders() {
    if (state.orders.length === 0) {
      renderEmpty();
      return;
    }

    elements.orderCount.textContent = `共 ${state.pagination.total} 条订单`;

    elements.orderList.innerHTML = state.orders.map(order => {
      const statusInfo = getOrderStatus(order.status);
      return `
        <div class="order-card">
          <div class="order-card-header">
            <div class="order-no">
              订单号：<span>${escapeHtml(order.order_no)}</span>
            </div>
            <div>
              <span class="order-time">${formatDate(order.created_at)}</span>
              <span class="order-status ${statusInfo.class}">${statusInfo.text}</span>
            </div>
          </div>
          <div class="order-card-body">
            <div class="order-info">
              <div class="info-row">
                <span class="info-label">收货人：</span>
                <span class="info-value">${escapeHtml(order.receiver_name)}</span>
                <span class="info-label" style="margin-left:16px">电话：</span>
                <span class="info-value">${escapeHtml(order.receiver_phone)}</span>
              </div>
              <div class="info-row">
                <span class="info-label">商品数量：</span>
                <span class="info-value">${order.item_count} 件</span>
                <span class="info-label" style="margin-left:16px">支付方式：</span>
                <span class="info-value">${order.payment_method === 'online' ? '在线支付' : order.payment_method}</span>
              </div>
            </div>
            <div class="order-amount">
              <span class="currency">¥</span>${formatAmount(order.total_amount)}
            </div>
          </div>
          <div class="order-card-footer">
            <span class="item-summary">收货地址：${escapeHtml(order.receiver_address || '-')}</span>
            <button class="detail-btn" onclick="viewOrderDetail(${order.id})">查看详情</button>
          </div>
        </div>
      `;
    }).join('');
  }

  /**
   * 渲染空状态
   */
  function renderEmpty() {
    elements.orderCount.textContent = '共 0 条订单';
    elements.orderList.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">📦</div>
        <p>暂无订单数据</p>
        <p style="font-size:13px">尝试调整筛选条件或搜索关键词</p>
      </div>
    `;
  }

  /**
   * 渲染分页
   */
  function renderPagination() {
    const { page, totalPages, total } = state.pagination;

    if (totalPages <= 1) {
      elements.pagination.innerHTML = '';
      return;
    }

    let html = '';

    // 上一页
    html += `<button ${page <= 1 ? 'disabled' : ''} onclick="goToPage(${page - 1})">上一页</button>`;

    // 页码按钮
    const maxButtons = 7;
    let startPage, endPage;

    if (totalPages <= maxButtons) {
      startPage = 1;
      endPage = totalPages;
    } else {
      const half = Math.floor(maxButtons / 2);
      if (page <= half + 1) {
        startPage = 1;
        endPage = maxButtons;
      } else if (page >= totalPages - half) {
        startPage = totalPages - maxButtons + 1;
        endPage = totalPages;
      } else {
        startPage = page - half;
        endPage = page + half;
      }
    }

    if (startPage > 1) {
      html += `<button onclick="goToPage(1)">1</button>`;
      if (startPage > 2) html += '<span class="page-info">...</span>';
    }

    for (let i = startPage; i <= endPage; i++) {
      html += `<button class="${i === page ? 'active' : ''}" onclick="goToPage(${i})">${i}</button>`;
    }

    if (endPage < totalPages) {
      if (endPage < totalPages - 1) html += '<span class="page-info">...</span>';
      html += `<button onclick="goToPage(${totalPages})">${totalPages}</button>`;
    }

    // 下一页
    html += `<button ${page >= totalPages ? 'disabled' : ''} onclick="goToPage(${page + 1})">下一页</button>`;

    // 页码信息
    html += `<span class="page-info">第 ${page}/${totalPages} 页，共 ${total} 条</span>`;

    elements.pagination.innerHTML = html;
  }

  /**
   * 渲染订单详情弹窗
   */
  function renderOrderDetail(order) {
    const statusInfo = getOrderStatus(order.status);

    let itemsHtml = '';
    if (order.items && order.items.length > 0) {
      itemsHtml = `
        <table class="order-items-table">
          <thead>
            <tr>
              <th>商品名称</th>
              <th>单价</th>
              <th>数量</th>
              <th class="text-right">小计</th>
            </tr>
          </thead>
          <tbody>
            ${order.items.map(item => `
              <tr>
                <td>${escapeHtml(item.product_name)}</td>
                <td>¥${formatAmount(item.product_price)}</td>
                <td>${item.quantity}</td>
                <td class="text-right">¥${formatAmount(item.subtotal)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
    }

    elements.modalBody.innerHTML = `
      <div class="detail-section">
        <h4>订单信息</h4>
        <div class="detail-row">
          <span class="detail-label">订单编号</span>
          <span class="detail-value">${escapeHtml(order.order_no)}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">订单状态</span>
          <span class="detail-value"><span class="order-status ${statusInfo.class}">${statusInfo.text}</span></span>
        </div>
        <div class="detail-row">
          <span class="detail-label">下单时间</span>
          <span class="detail-value">${formatDate(order.created_at)}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">支付方式</span>
          <span class="detail-value">${order.payment_method === 'online' ? '在线支付' : order.payment_method}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">订单金额</span>
          <span class="detail-value" style="color:#ff4d4f;font-weight:600">¥${formatAmount(order.total_amount)}</span>
        </div>
        ${order.remark ? `
        <div class="detail-row">
          <span class="detail-label">备注</span>
          <span class="detail-value">${escapeHtml(order.remark)}</span>
        </div>` : ''}
      </div>

      <div class="detail-section">
        <h4>收货信息</h4>
        <div class="detail-row">
          <span class="detail-label">收货人</span>
          <span class="detail-value">${escapeHtml(order.receiver_name)}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">联系电话</span>
          <span class="detail-value">${escapeHtml(order.receiver_phone)}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">收货地址</span>
          <span class="detail-value">${escapeHtml(order.receiver_address)}</span>
        </div>
      </div>

      <div class="detail-section">
        <h4>商品明细</h4>
        ${itemsHtml || '<p style="color:#8c8c8c">暂无商品信息</p>'}
      </div>
    `;

    showModal();
  }

  // ==================== 弹窗控制 ====================

  function showModal() {
    elements.modalOverlay.style.display = 'flex';
  }

  function closeModal() {
    elements.modalOverlay.style.display = 'none';
  }

  // ==================== 页面跳转 ====================

  window.goToPage = function(page) {
    if (page < 1 || page > state.pagination.totalPages) return;
    state.pagination.page = page;
    loadOrders();
    // 滚动到顶部
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  window.viewOrderDetail = function(orderId) {
    loadOrderDetail(orderId);
  };

  // ==================== 工具函数 ====================

  /**
   * HTML 转义，防止 XSS
   */
  function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  // ==================== 启动 ====================
  init();
});

/**
 * API 请求封装模块
 * 基于 Axios 实现统一请求管理
 * 
 * 功能：
 * - 请求/响应拦截
 * - 自动携带 Token
 * - 统一错误处理
 * - Token 过期自动跳转登录
 */

const BASE_URL = 'http://localhost:3000';

// 创建 Axios 实例
const api = axios.create({
  baseURL: BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json'
  }
});

/**
 * 请求拦截器
 * 在每次请求发送前，自动从 localStorage 读取 Token 并添加到请求头
 */
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

/**
 * 响应拦截器
 * 统一处理响应数据和错误
 */
api.interceptors.response.use(
  (response) => {
    // 直接返回 data，简化调用方代码
    return response.data;
  },
  (error) => {
    // 处理网络错误
    if (!error.response) {
      return Promise.reject({
        code: 0,
        message: '网络连接失败，请检查网络'
      });
    }

    const { status, data } = error.response;

    // Token 过期或无效，清除登录状态
    if (status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      // 如果不在登录页，则跳转
      if (!window.location.pathname.includes('index.html')) {
        window.location.href = '/index.html';
      }
    }

    return Promise.reject(data || { code: status, message: '请求失败' });
  }
);

// ==================== API 方法封装 ====================

/**
 * 认证相关 API
 */
const authAPI = {
  /**
   * 用户登录
   * @param {string} username - 用户名
   * @param {string} password - 密码
   * @returns {Promise<{token: string, user: Object}>}
   */
  login: (username, password) => {
    return api.post('/api/auth/login', { username, password });
  },

  /**
   * 获取当前用户信息
   * @returns {Promise<Object>}
   */
  getCurrentUser: () => {
    return api.get('/api/auth/me');
  }
};

/**
 * 订单相关 API
 */
const orderAPI = {
  /**
   * 查询订单列表
   * @param {Object} params - { page, pageSize, status, keyword }
   * @returns {Promise<{list: Array, pagination: Object}>}
   */
  getList: (params = {}) => {
    return api.get('/api/orders', { params });
  },

  /**
   * 查询订单详情
   * @param {number} id - 订单ID
   * @returns {Promise<Object>}
   */
  getDetail: (id) => {
    return api.get(`/api/orders/${id}`);
  }
};

/**
 * 商品相关 API
 */
const productAPI = {
  /**
   * 查询商品列表
   * @param {Object} params
   * @returns {Promise<{list: Array, pagination: Object}>}
   */
  getList: (params = {}) => {
    return api.get('/api/products', { params });
  },

  /**
   * 查询商品详情
   * @param {number} id
   * @returns {Promise<Object>}
   */
  getDetail: (id) => {
    return api.get(`/api/products/${id}`);
  }
};

// ==================== 工具函数 ====================

/**
 * Toast 提示
 */
function showToast(message, type = 'info', duration = 3000) {
  // 移除已有 toast
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.style.animation = 'fadeInDown 0.3s ease reverse';
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

/**
 * 格式化日期
 */
function formatDate(dateStr) {
  if (!dateStr) return '-';
  const date = new Date(dateStr);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  return `${year}-${month}-${day} ${hours}:${minutes}`;
}

/**
 * 格式化金额
 */
function formatAmount(amount) {
  return Number(amount).toFixed(2);
}

/**
 * 订单状态映射
 */
const ORDER_STATUS_MAP = {
  'pending': { text: '待支付', class: 'status-pending' },
  'paid': { text: '已支付', class: 'status-paid' },
  'shipped': { text: '已发货', class: 'status-shipped' },
  'delivered': { text: '已完成', class: 'status-delivered' },
  'cancelled': { text: '已取消', class: 'status-cancelled' }
};

/**
 * 获取订单状态显示
 */
function getOrderStatus(status) {
  return ORDER_STATUS_MAP[status] || { text: status, class: '' };
}

/**
 * 检查登录状态
 */
function checkAuth() {
  const token = localStorage.getItem('token');
  const user = localStorage.getItem('user');
  if (!token || !user) {
    window.location.href = '/index.html';
    return null;
  }
  try {
    return JSON.parse(user);
  } catch {
    localStorage.clear();
    window.location.href = '/index.html';
    return null;
  }
}

/**
 * 退出登录
 */
function logout() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  window.location.href = '/index.html';
}

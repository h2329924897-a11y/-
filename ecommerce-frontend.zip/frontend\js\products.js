/**
 * products.js - 商品列表页面逻辑
 *
 * 核心功能：
 *   - 商品列表分页查询（每页一次请求）
 *   - 分类筛选
 *   - 关键词搜索
 *   - 排序（价格/销量/时间）
 *   - 每页条数切换
 *   - Mock 模式切换（无需后端即可演示）
 *   - 商品详情弹窗
 *
 * 请求方式：
 *   - Mock 模式：调用 MockAPI.getProductList()，每次翻页/筛选触发独立调用
 *   - 真实 API：调用 request.get('/api/products', params)
 */

(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {

    // ==================== 状态管理 ====================
    var state = {
      products: [],
      pagination: {
        page: 1,
        pageSize: 12,
        total: 0,
        totalPages: 0,
      },
      filters: {
        keyword: '',
        category: '',
        sortBy: 'id',
        sortOrder: 'ASC',
      },
      categories: [],
      currentUser: null,
      // Mock 模式（默认关闭，可通过开关切换）
      useMock: false,
    };

    // ==================== DOM 元素引用 ====================
    var elements = {
      userName:       document.getElementById('userName'),
      userRole:       document.getElementById('userRole'),
      productGrid:    document.getElementById('productGrid'),
      productCount:   document.getElementById('productCount'),
      searchKeyword:  document.getElementById('searchKeyword'),
      categoryFilter: document.getElementById('categoryFilter'),
      sortBy:         document.getElementById('sortBy'),
      sortOrder:      document.getElementById('sortOrder'),
      pageSize:       document.getElementById('pageSize'),
      searchBtn:      document.getElementById('searchBtn'),
      resetBtn:       document.getElementById('resetBtn'),
      pagination:     document.getElementById('pagination'),
      mockToggle:     document.getElementById('mockToggle'),
      modalOverlay:   document.getElementById('modalOverlay'),
      modalBody:      document.getElementById('modalBody'),
      modalClose:     document.getElementById('modalClose'),
      logoutBtn:      document.getElementById('logoutBtn'),
    };

    // ==================== 初始化 ====================
    function init() {
      // 检查登录状态
      var user = checkAuth();
      if (!user) return;
      state.currentUser = user;

      // 渲染用户信息
      renderUserInfo();

      // 初始化分类下拉
      initCategories();

      // 加载商品列表
      loadProducts();

      // 绑定事件
      bindEvents();
    }

    /**
     * 初始化分类下拉选项
     */
    function initCategories() {
      // 优先使用 Mock 定义的分类，否则使用后端 API
      if (typeof CATEGORIES !== 'undefined') {
        state.categories = CATEGORIES;
        renderCategoryOptions();
      }
    }

    function renderCategoryOptions() {
      var optionsHtml = '<option value="">全部分类</option>';
      state.categories.forEach(function (cat) {
        optionsHtml += '<option value="' + cat.id + '">' + escapeHtml(cat.name) + '</option>';
      });
      elements.categoryFilter.innerHTML = optionsHtml;
    }

    /**
     * 渲染顶部用户信息
     */
    function renderUserInfo() {
      var user = state.currentUser;
      elements.userName.textContent = user.nickname || user.username;
      elements.userRole.textContent = user.role === 'admin' ? '管理员' : '普通用户';
      if (user.role === 'admin') {
        elements.userRole.classList.add('admin');
      }
    }

    // ==================== 事件绑定 ====================
    function bindEvents() {
      // 搜索按钮
      elements.searchBtn.addEventListener('click', function () {
        state.filters.keyword = elements.searchKeyword.value.trim();
        state.filters.category = elements.categoryFilter.value;
        state.filters.sortBy = elements.sortBy.value;
        state.filters.sortOrder = elements.sortOrder.value;
        state.pagination.pageSize = parseInt(elements.pageSize.value);
        state.pagination.page = 1;
        loadProducts();
      });

      // 重置按钮
      elements.resetBtn.addEventListener('click', function () {
        elements.searchKeyword.value = '';
        elements.categoryFilter.value = '';
        elements.sortBy.value = 'id';
        elements.sortOrder.value = 'ASC';
        elements.pageSize.value = '12';
        state.filters = { keyword: '', category: '', sortBy: 'id', sortOrder: 'ASC' };
        state.pagination = { page: 1, pageSize: 12, total: 0, totalPages: 0 };
        loadProducts();
      });

      // 回车搜索
      elements.searchKeyword.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
          elements.searchBtn.click();
        }
      });

      // 分类筛选变化时自动搜索
      elements.categoryFilter.addEventListener('change', function () {
        state.filters.category = elements.categoryFilter.value;
        state.pagination.page = 1;
        loadProducts();
      });

      // 排序方式变化
      elements.sortBy.addEventListener('change', function () {
        state.filters.sortBy = elements.sortBy.value;
        state.pagination.page = 1;
        loadProducts();
      });

      elements.sortOrder.addEventListener('change', function () {
        state.filters.sortOrder = elements.sortOrder.value;
        state.pagination.page = 1;
        loadProducts();
      });

      // 每页条数变化
      elements.pageSize.addEventListener('change', function () {
        state.pagination.pageSize = parseInt(elements.pageSize.value);
        state.pagination.page = 1;
        loadProducts();
      });

      // Mock 模式切换
      elements.mockToggle.addEventListener('change', function () {
        state.useMock = elements.mockToggle.checked;
        // 同步设置到 request 工具
        if (typeof request !== 'undefined') {
          request.setMockMode(state.useMock);
        }
        state.pagination.page = 1;
        loadProducts();
        showToast(
          state.useMock ? '已切换到 Mock 数据模式' : '已切换到真实 API 模式',
          state.useMock ? 'warning' : 'info'
        );
      });

      // 退出登录
      elements.logoutBtn.addEventListener('click', function () {
        if (confirm('确定要退出登录吗？')) {
          logout();
        }
      });

      // 关闭弹窗（点击遮罩）
      elements.modalOverlay.addEventListener('click', function (e) {
        if (e.target === elements.modalOverlay) {
          closeModal();
        }
      });

      // 关闭弹窗（点击关闭按钮）
      elements.modalClose.addEventListener('click', closeModal);

      // ESC 关闭弹窗
      document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
          closeModal();
        }
      });
    }

    // ==================== 数据加载 ====================

    /**
     * 加载商品列表（分页 + 筛选）
     *
     * 核心：每次翻页/筛选都会发送一次独立的异步请求
     */
    async function loadProducts() {
      try {
        // 显示加载状态
        elements.productGrid.innerHTML =
          '<div class="loading">' +
          '  <div class="spinner-large"></div>' +
          '  <p>正在加载商品...</p>' +
          '</div>';
        elements.pagination.innerHTML = '';

        var params = {
          page:      state.pagination.page,
          pageSize:  state.pagination.pageSize,
          keyword:   state.filters.keyword,
          category:  state.filters.category,
          sortBy:    state.filters.sortBy,
          sortOrder: state.filters.sortOrder,
        };

        var response;

        if (state.useMock) {
          // ---------- Mock 模式 ----------
          // 每次调用 MockAPI.getProductList 都是一次独立的异步请求
          response = await MockAPI.getProductList(params);
        } else {
          // ---------- 真实 API 模式 ----------
          // 使用 request.js 封装的 get 方法
          response = await request.get('/api/products', params);
        }

        if (response.code === 200) {
          state.products = response.data.list;
          state.pagination = response.data.pagination;

          renderProducts();
          renderPagination();
        } else {
          showToast(response.message || '加载商品失败', 'error');
          renderEmpty();
        }
      } catch (error) {
        console.error('[商品加载] 错误:', error);
        showToast(error.message || '加载商品失败', 'error');
        renderEmpty();
      }
    }

    /**
     * 加载商品详情
     */
    async function loadProductDetail(productId) {
      try {
        // 显示加载状态
        elements.modalBody.innerHTML =
          '<div class="loading">' +
          '  <div class="spinner-large"></div>' +
          '  <p>正在加载商品详情...</p>' +
          '</div>';
        showModal();

        var response;

        if (state.useMock) {
          response = await MockAPI.getProductDetail(productId);
        } else {
          response = await request.get('/api/products/' + productId);
        }

        if (response.code === 200) {
          renderProductDetail(response.data);
        } else {
          elements.modalBody.innerHTML =
            '<p style="text-align:center;color:#ff4d4f;">' +
            (response.message || '加载失败') +
            '</p>';
        }
      } catch (error) {
        console.error('[商品详情] 错误:', error);
        elements.modalBody.innerHTML =
          '<p style="text-align:center;color:#ff4d4f;">' +
          (error.message || '加载失败') +
          '</p>';
      }
    }

    // ==================== 渲染函数 ====================

    /**
     * 渲染商品网格列表
     */
    function renderProducts() {
      if (state.products.length === 0) {
        renderEmpty();
        return;
      }

      elements.productCount.textContent =
        '共 ' + state.pagination.total + ' 件商品';

      elements.productGrid.innerHTML = state.products.map(function (product) {
        var categoryName = '';
        if (typeof CATEGORY_MAP !== 'undefined') {
          categoryName = CATEGORY_MAP[product.category_id] || product.category_id;
        } else {
          categoryName = product.category || product.category_id || '';
        }

        return (
          '<div class="product-card" onclick="viewProductDetail(' + product.id + ')">' +
            // 商品图片占位
            '<div class="product-card-image">' +
              '<span class="product-card-icon">📦</span>' +
              (categoryName
                ? '<span class="product-card-category">' + escapeHtml(categoryName) + '</span>'
                : '') +
            '</div>' +
            // 商品信息
            '<div class="product-card-info">' +
              '<h4 class="product-card-name">' + escapeHtml(product.name) + '</h4>' +
              '<p class="product-card-desc">' + escapeHtml(product.description || '') + '</p>' +
              '<div class="product-card-meta">' +
                '<span class="product-card-sales">已售 ' + (product.sales || 0) + '</span>' +
                '<span class="product-card-stock">库存 ' + (product.stock || 0) + '</span>' +
              '</div>' +
              '<div class="product-card-bottom">' +
                '<span class="product-card-price">' +
                  '<span class="currency">¥</span>' + formatAmount(product.price) +
                '</span>' +
                '<button class="detail-btn" onclick="event.stopPropagation();viewProductDetail(' + product.id + ')">查看详情</button>' +
              '</div>' +
            '</div>' +
          '</div>'
        );
      }).join('');
    }

    /**
     * 渲染空状态
     */
    function renderEmpty() {
      elements.productCount.textContent = '共 0 件商品';
      elements.productGrid.innerHTML =
        '<div class="empty-state">' +
        '  <div class="empty-icon">📦</div>' +
        '  <p>暂无商品数据</p>' +
        '  <p style="font-size:13px">尝试调整筛选条件或搜索关键词</p>' +
        '</div>';
    }

    /**
     * 渲染分页
     */
    function renderPagination() {
      var page = state.pagination.page;
      var totalPages = state.pagination.totalPages;
      var total = state.pagination.total;

      if (totalPages <= 1) {
        elements.pagination.innerHTML = '';
        return;
      }

      var html = '';

      // 上一页
      html += '<button ' + (page <= 1 ? 'disabled' : '') +
              ' onclick="goToPage(' + (page - 1) + ')">上一页</button>';

      // 页码按钮
      var maxButtons = 7;
      var startPage, endPage;

      if (totalPages <= maxButtons) {
        startPage = 1;
        endPage = totalPages;
      } else {
        var half = Math.floor(maxButtons / 2);
        if (page <= half + 1) {
          startPage = 1;
          endPage = maxButtons;
        } else if (page >= totalPages - half) {
          startPage = totalPages - maxButtons + 1;
          endPage = totalPages;
        } else {
          startPage = page - half;
          endPage = page + half;
        }
      }

      if (startPage > 1) {
        html += '<button onclick="goToPage(1)">1</button>';
        if (startPage > 2) html += '<span class="page-info">...</span>';
      }

      for (var i = startPage; i <= endPage; i++) {
        html += '<button class="' + (i === page ? 'active' : '') +
                '" onclick="goToPage(' + i + ')">' + i + '</button>';
      }

      if (endPage < totalPages) {
        if (endPage < totalPages - 1) html += '<span class="page-info">...</span>';
        html += '<button onclick="goToPage(' + totalPages + ')">' + totalPages + '</button>';
      }

      // 下一页
      html += '<button ' + (page >= totalPages ? 'disabled' : '') +
              ' onclick="goToPage(' + (page + 1) + ')">下一页</button>';

      // 页码信息
      html += '<span class="page-info">第 ' + page + '/' + totalPages +
              ' 页，共 ' + total + ' 条</span>';

      elements.pagination.innerHTML = html;
    }

    /**
     * 渲染商品详情弹窗
     */
    function renderProductDetail(product) {
      var categoryName = '';
      if (typeof CATEGORY_MAP !== 'undefined') {
        categoryName = CATEGORY_MAP[product.category_id] || product.category_id;
      } else {
        categoryName = product.category || product.category_id || '';
      }

      elements.modalBody.innerHTML =
        '<div class="product-detail">' +
          // 图片区域
          '<div class="product-detail-image">' +
            '<span class="product-detail-icon">📦</span>' +
          '</div>' +
          // 基本信息
          '<div class="product-detail-section">' +
            '<h3 class="product-detail-name">' + escapeHtml(product.name) + '</h3>' +
            (categoryName
              ? '<span class="product-detail-category">' + escapeHtml(categoryName) + '</span>'
              : '') +
          '</div>' +
          // 价格
          '<div class="product-detail-price-row">' +
            '<span class="product-detail-price">' +
              '¥' + formatAmount(product.price) +
            '</span>' +
          '</div>' +
          // 描述
          '<div class="product-detail-section">' +
            '<h4>商品描述</h4>' +
            '<p class="product-detail-desc">' +
              escapeHtml(product.description || '暂无描述') +
            '</p>' +
          '</div>' +
          // 销售信息
          '<div class="product-detail-section">' +
            '<h4>销售信息</h4>' +
            '<div class="detail-row">' +
              '<span class="detail-label">销量</span>' +
              '<span class="detail-value">' + (product.sales || 0) + ' 件</span>' +
            '</div>' +
            '<div class="detail-row">' +
              '<span class="detail-label">库存</span>' +
              '<span class="detail-value">' + (product.stock || 0) + ' 件</span>' +
            '</div>' +
            '<div class="detail-row">' +
              '<span class="detail-label">上架时间</span>' +
              '<span class="detail-value">' + formatDate(product.created_at) + '</span>' +
            '</div>' +
          '</div>' +
        '</div>';

      showModal();
    }

    // ==================== 弹窗控制 ====================
    function showModal() {
      elements.modalOverlay.style.display = 'flex';
      document.body.style.overflow = 'hidden';
    }

    function closeModal() {
      elements.modalOverlay.style.display = 'none';
      document.body.style.overflow = '';
    }

    // ==================== 页面跳转（暴露给 HTML onclick） ====================
    window.goToPage = function (page) {
      if (page < 1 || page > state.pagination.totalPages) return;
      state.pagination.page = page;
      // ★ 核心：每次翻页都是一次独立的异步请求
      loadProducts();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    window.viewProductDetail = function (productId) {
      loadProductDetail(productId);
    };

    // ==================== 工具函数 ====================
    function escapeHtml(text) {
      if (!text) return '';
      var div = document.createElement('div');
      div.textContent = text;
      return div.innerHTML;
    }

    // ==================== 启动 ====================
    init();
  });

})();

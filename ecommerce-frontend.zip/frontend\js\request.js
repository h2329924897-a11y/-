/**
 * request.js - 独立异步请求工具模块
 * 基于 Axios 封装，提供统一的 HTTP 请求管理
 *
 * 核心能力：
 *   - 请求/响应拦截器
 *   - 自动携带 JWT Token
 *   - 超时控制 + 重试机制
 *   - 统一错误处理
 *   - 请求取消（AbortController）
 *   - 支持 Mock 模式切换
 *   - 并发请求控制
 */

(function (global) {
  'use strict';

  // ==================== 配置 ====================
  const CONFIG = {
    // 基础 API 地址
    BASE_URL: 'http://localhost:3000',
    // 请求超时（毫秒）
    TIMEOUT: 15000,
    // 最大重试次数
    MAX_RETRIES: 2,
    // 重试间隔（毫秒）
    RETRY_DELAY: 1000,
    // 是否启用 Mock 模式（true 时使用 Mock 数据，不发送真实请求）
    USE_MOCK: false,
  };

  // ==================== 状态管理 ====================
  // 正在进行的请求映射（用于取消重复请求）
  const pendingRequests = new Map();

  /**
   * 生成请求唯一标识
   */
  function getRequestKey(config) {
    const { method, url, params, data } = config;
    return [method, url, JSON.stringify(params), JSON.stringify(data)].join('&');
  }

  /**
   * 添加待处理请求
   */
  function addPending(config) {
    const key = getRequestKey(config);
    // 如果已有相同请求在进行中，取消前一个
    if (pendingRequests.has(key)) {
      const controller = pendingRequests.get(key);
      controller.abort();
    }
    const controller = new AbortController();
    config.signal = controller.signal;
    pendingRequests.set(key, controller);
    return config;
  }

  /**
   * 移除待处理请求
   */
  function removePending(config) {
    const key = getRequestKey(config);
    pendingRequests.delete(key);
  }

  // ==================== Axios 实例 ====================
  const instance = axios.create({
    baseURL: CONFIG.BASE_URL,
    timeout: CONFIG.TIMEOUT,
    headers: {
      'Content-Type': 'application/json',
    },
  });

  /**
   * 请求拦截器
   * - 自动附加 Token
   * - 取消重复请求
   */
  instance.interceptors.request.use(
    function (config) {
      // 附加 JWT Token
      const token = localStorage.getItem('token');
      if (token) {
        config.headers.Authorization = 'Bearer ' + token;
      }

      // 取消重复请求（GET 请求）
      if (config.method === 'get') {
        config = addPending(config);
      }

      return config;
    },
    function (error) {
      return Promise.reject(error);
    }
  );

  /**
   * 响应拦截器
   * - 简化返回值
   * - 统一错误处理
   * - 401 自动跳转登录
   */
  instance.interceptors.response.use(
    function (response) {
      removePending(response.config);
      // 直接返回 data，简化调用方代码
      return response.data;
    },
    function (error) {
      if (error.config) {
        removePending(error.config);
      }

      // 请求被取消
      if (axios.isCancel(error)) {
        return Promise.reject({
          code: -1,
          message: '请求已取消',
          cancelled: true,
        });
      }

      // 网络错误（无响应）
      if (!error.response) {
        return Promise.reject({
          code: 0,
          message: '网络连接失败，请检查网络',
        });
      }

      var status = error.response.status;
      var data = error.response.data;

      // Token 过期或无效
      if (status === 401) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        if (!window.location.pathname.includes('index.html')) {
          window.location.href = '/index.html';
        }
      }

      return Promise.reject(
        data || { code: status, message: '请求失败 (' + status + ')' }
      );
    }
  );

  // ==================== 核心请求方法 ====================

  /**
   * 判断错误是否应该重试
   */
  function shouldRetry(error) {
    // 网络错误或服务器错误时重试
    if (!error.response) return true;
    var status = error.response.status;
    return status >= 500 || status === 429 || status === 408;
  }

  /**
   * 延迟函数
   */
  function delay(ms) {
    return new Promise(function (resolve) {
      setTimeout(resolve, ms);
    });
  }

  /**
   * 发起 GET 请求
   */
  async function get(url, params, options) {
    options = options || {};
    var config = { params: params };

    // 支持自定义超时
    if (options.timeout) {
      config.timeout = options.timeout;
    }

    // 支持取消
    if (options.signal) {
      config.signal = options.signal;
    }

    var retries = options.retries !== undefined ? options.retries : CONFIG.MAX_RETRIES;

    for (var attempt = 0; attempt <= retries; attempt++) {
      try {
        return await instance.get(url, config);
      } catch (error) {
        // 最后一次尝试，直接抛出
        if (attempt >= retries) throw error;
        // 不重试的情况
        if (!shouldRetry(error)) throw error;
        // 等待后重试
        console.warn('[request] 请求失败，正在重试 (' + (attempt + 1) + '/' + retries + '):', url);
        await delay(CONFIG.RETRY_DELAY * (attempt + 1));
      }
    }
  }

  /**
   * 发起 POST 请求
   */
  async function post(url, data, options) {
    options = options || {};
    var config = {};

    if (options.timeout) {
      config.timeout = options.timeout;
    }
    if (options.signal) {
      config.signal = options.signal;
    }

    return instance.post(url, data, config);
  }

  /**
   * 发起 PUT 请求
   */
  async function put(url, data, options) {
    options = options || {};
    var config = {};

    if (options.timeout) {
      config.timeout = options.timeout;
    }

    return instance.put(url, data, config);
  }

  /**
   * 发起 DELETE 请求
   */
  async function del(url, options) {
    options = options || {};
    var config = {};

    if (options.timeout) {
      config.timeout = options.timeout;
    }

    return instance.delete(url, config);
  }

  /**
   * 并发请求（同时发送多个请求，全部完成后返回）
   */
  async function all(requests) {
    return Promise.all(requests);
  }

  /**
   * 竞速请求（取最先完成的请求结果）
   */
  async function race(requests) {
    return Promise.race(requests);
  }

  /**
   * 顺序执行请求（上一个完成才发下一个）
   */
  async function sequence(requestFns) {
    var results = [];
    for (var i = 0; i < requestFns.length; i++) {
      results.push(await requestFns[i]());
    }
    return results;
  }

  // ==================== 对外暴露 ====================

  /**
   * request 工具对象
   * 提供 get / post / put / del 四个主要方法
   */
  var request = {
    // 基础方法
    get: get,
    post: post,
    put: put,
    del: del,

    // 高级方法
    all: all,
    race: race,
    sequence: sequence,

    // 配置
    config: CONFIG,

    /**
     * 获取 Axios 原始实例（高级用法）
     */
    getInstance: function () {
      return instance;
    },

    /**
     * 切换 Mock 模式
     */
    setMockMode: function (enabled) {
      CONFIG.USE_MOCK = enabled;
    },

    /**
     * 取消所有正在进行的请求
     */
    cancelAll: function () {
      pendingRequests.forEach(function (controller) {
        controller.abort();
      });
      pendingRequests.clear();
    },

    /**
     * 设置基础 URL
     */
    setBaseURL: function (url) {
      CONFIG.BASE_URL = url;
      instance.defaults.baseURL = url;
    },
  };

  // 挂载到全局
  global.request = request;

})(window);

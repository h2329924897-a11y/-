/**
 * 订单模型 - 数据访问层
 * 封装订单相关的数据库操作
 */

const db = require('../config/db');

const OrderModel = {
  /**
   * 查询用户订单列表（分页）
   * @param {number} userId - 用户ID
   * @param {Object} options - 查询选项 { page, pageSize, status, keyword }
   * @returns {Promise<{list: Array, total: number}>}
   */
  findByUserId: async (userId, options = {}) => {
    const {
      page = 1,
      pageSize = 10,
      status = null,
      keyword = null
    } = options;

    const offset = (page - 1) * pageSize;
    let whereClause = 'WHERE o.user_id = ?';
    const params = [userId];

    // 按订单状态筛选
    if (status) {
      whereClause += ' AND o.status = ?';
      params.push(status);
    }

    // 按订单号或商品名模糊搜索
    if (keyword) {
      whereClause += ' AND (o.order_no LIKE ? OR p.name LIKE ?)';
      params.push(`%${keyword}%`, `%${keyword}%`);
    }

    // 查询总数
    const countSql = `
      SELECT COUNT(DISTINCT o.id) as total
      FROM orders o
      LEFT JOIN order_items oi ON o.id = oi.order_id
      LEFT JOIN products p ON oi.product_id = p.id
      ${whereClause}
    `;
    const countResult = await db.queryOne(countSql, params);
    const total = countResult ? countResult.total : 0;

    // 查询订单列表（含订单项汇总）
    const listSql = `
      SELECT 
        o.id,
        o.order_no,
        o.user_id,
        o.total_amount,
        o.status,
        o.receiver_name,
        o.receiver_phone,
        o.receiver_address,
        o.payment_method,
        o.remark,
        o.created_at,
        o.updated_at,
        COUNT(oi.id) as item_count
      FROM orders o
      LEFT JOIN order_items oi ON o.id = oi.order_id
      LEFT JOIN products p ON oi.product_id = p.id
      ${whereClause}
      GROUP BY o.id
      ORDER BY o.created_at DESC
      LIMIT ? OFFSET ?
    `;

    const list = await db.query(listSql, [...params, pageSize, offset]);

    return { list, total, page, pageSize };
  },

  /**
   * 查询订单详情（含订单项）
   * @param {number} orderId
   * @param {number} userId - 用于权限校验
   * @returns {Promise<Object|null>}
   */
  findById: async (orderId, userId) => {
    const order = await db.queryOne(
      `SELECT * FROM orders WHERE id = ? AND user_id = ?`,
      [orderId, userId]
    );

    if (!order) return null;

    // 查询订单项
    const items = await db.query(
      `SELECT oi.*, p.name as product_name, p.image_url as product_image
       FROM order_items oi
       LEFT JOIN products p ON oi.product_id = p.id
       WHERE oi.order_id = ?`,
      [orderId]
    );

    return { ...order, items };
  },

  /**
   * 查询所有订单（管理员）
   * @param {Object} options
   * @returns {Promise<{list: Array, total: number}>}
   */
  findAll: async (options = {}) => {
    const {
      page = 1,
      pageSize = 10,
      status = null,
      keyword = null
    } = options;

    const offset = (page - 1) * pageSize;
    let whereClause = 'WHERE 1=1';
    const params = [];

    if (status) {
      whereClause += ' AND o.status = ?';
      params.push(status);
    }

    if (keyword) {
      whereClause += ' AND (o.order_no LIKE ? OR u.username LIKE ?)';
      params.push(`%${keyword}%`, `%${keyword}%`);
    }

    const countResult = await db.queryOne(
      `SELECT COUNT(*) as total FROM orders o LEFT JOIN users u ON o.user_id = u.id ${whereClause}`,
      params
    );

    const list = await db.query(
      `SELECT o.*, u.username, u.nickname
       FROM orders o
       LEFT JOIN users u ON o.user_id = u.id
       ${whereClause}
       ORDER BY o.created_at DESC
       LIMIT ? OFFSET ?`,
      [...params, pageSize, offset]
    );

    return {
      list,
      total: countResult.total,
      page,
      pageSize
    };
  }
};

module.exports = OrderModel;

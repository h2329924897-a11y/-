/**
 * 自定义应用错误类
 * 用于统一错误处理，携带 HTTP 状态码和业务错误码
 */
class AppError extends Error {
  /**
   * @param {string} message - 错误信息
   * @param {number} statusCode - HTTP 状态码
   * @param {number} code - 业务错误码
   */
  constructor(message, statusCode = 500, code = statusCode) {
    super(message);
    this.name = 'AppError';
    this.statusCode = statusCode;
    this.code = code;
    this.isOperational = true; // 标记为可预见的操作错误
    Error.captureStackTrace(this, this.constructor);
  }
}

module.exports = AppError;

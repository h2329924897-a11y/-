/**
 * 商品模型 - 数据访问层
 */

const db = require('../config/db');

const ProductModel = {
  /**
   * 查询商品列表（分页 + 搜索 + 排序）
   */
  findAll: async (options = {}) => {
    const {
      page = 1,
      pageSize = 10,
      keyword = null,
      category = null,
      sortBy = 'created_at',
      sortOrder = 'DESC'
    } = options;

    const offset = (page - 1) * pageSize;
    let whereClause = 'WHERE status = 1';
    const params = [];

    if (keyword) {
      whereClause += ' AND (name LIKE ? OR description LIKE ?)';
      params.push(`%${keyword}%`, `%${keyword}%`);
    }

    if (category) {
      whereClause += ' AND category = ?';
      params.push(category);
    }

    // 排序白名单
    const allowedSortFields = ['price', 'sales', 'created_at', 'name'];
    const field = allowedSortFields.includes(sortBy) ? sortBy : 'created_at';
    const order = sortOrder.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

    const countResult = await db.queryOne(
      `SELECT COUNT(*) as total FROM products ${whereClause}`,
      params
    );

    const list = await db.query(
      `SELECT id, name, category, price, original_price, image_url, description, sales, stock, status, created_at
       FROM products ${whereClause}
       ORDER BY ${field} ${order}
       LIMIT ? OFFSET ?`,
      [...params, pageSize, offset]
    );

    return {
      list,
      total: countResult.total,
      page,
      pageSize
    };
  },

  /**
   * 查询商品详情
   */
  findById: async (id) => {
    return db.queryOne(
      'SELECT * FROM products WHERE id = ?',
      [id]
    );
  }
};

module.exports = ProductModel;

/**
 * 商品路由
 */

const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');
const { optionalAuth } = require('../middleware/auth');

// GET /api/products - 商品列表（可选认证）
router.get('/', optionalAuth, productController.list);

// GET /api/products/:id - 商品详情
router.get('/:id', productController.detail);

module.exports = router;

/**
 * 日志工具模块
 * 提供分级日志记录功能，支持开发/生产环境切换
 */

const LOG_LEVELS = {
  DEBUG: 0,
  INFO: 1,
  WARN: 2,
  ERROR: 3
};

const CURRENT_LEVEL = process.env.NODE_ENV === 'production'
  ? LOG_LEVELS.INFO
  : LOG_LEVELS.DEBUG;

function getTimestamp() {
  return new Date().toISOString();
}

function formatMessage(level, module, message, data) {
  const timestamp = getTimestamp();
  const prefix = `[${timestamp}] [${level}] [${module}]`;
  if (data !== undefined) {
    return `${prefix} ${message}`, data;
  }
  return `${prefix} ${message}`;
}

const logger = {
  debug(module, message, data) {
    if (CURRENT_LEVEL <= LOG_LEVELS.DEBUG) {
      console.debug(formatMessage('DEBUG', module, message, data));
    }
  },

  info(module, message, data) {
    if (CURRENT_LEVEL <= LOG_LEVELS.INFO) {
      console.log(formatMessage('INFO', module, message, data));
    }
  },

  warn(module, message, data) {
    if (CURRENT_LEVEL <= LOG_LEVELS.WARN) {
      console.warn(formatMessage('WARN', module, message, data));
    }
  },

  error(module, message, error) {
    if (CURRENT_LEVEL <= LOG_LEVELS.ERROR) {
      console.error(formatMessage('ERROR', module, message));
      if (error && error.stack) {
        console.error(error.stack);
      } else if (error) {
        console.error(error);
      }
    }
  }
};

module.exports = logger;

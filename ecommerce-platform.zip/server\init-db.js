/**
 * 数据库初始化脚本
 * 创建数据库表并插入测试数据
 * 
 * 运行方式：node server/init-db.js
 */
require('dotenv').config();
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const config = require('./config');
const logger = require('./utils/logger');

const DB_NAME = config.db.database;

async function initDatabase() {
  let connection;

  try {
    // 1. 创建连接（不指定数据库）
    connection = await mysql.createConnection({
      host: config.db.host,
      port: config.db.port,
      user: config.db.user,
      password: config.db.password
    });
    logger.info('InitDB', '数据库连接成功');

    // 2. 创建数据库
    await connection.execute(
      `CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
    );
    logger.info('InitDB', `数据库 "${DB_NAME}" 创建成功`);

    // 3. 切换到目标数据库
    await connection.execute(`USE \`${DB_NAME}\``);

    // 4. 创建用户表
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
        password VARCHAR(255) NOT NULL COMMENT '密码(bcrypt哈希)',
        nickname VARCHAR(50) DEFAULT '' COMMENT '昵称',
        email VARCHAR(100) DEFAULT '' COMMENT '邮箱',
        phone VARCHAR(20) DEFAULT '' COMMENT '手机号',
        role ENUM('user', 'admin') DEFAULT 'user' COMMENT '角色',
        status TINYINT DEFAULT 1 COMMENT '状态: 1-启用 0-禁用',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_username (username),
        INDEX idx_role (role)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表'
    `);
    logger.info('InitDB', '用户表创建成功');

    // 5. 创建商品表
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS products (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(200) NOT NULL COMMENT '商品名称',
        category VARCHAR(50) DEFAULT '' COMMENT '商品分类',
        price DECIMAL(10,2) NOT NULL COMMENT '售价',
        original_price DECIMAL(10,2) DEFAULT NULL COMMENT '原价',
        image_url VARCHAR(500) DEFAULT '' COMMENT '商品图片URL',
        description TEXT COMMENT '商品描述',
        sales INT DEFAULT 0 COMMENT '销量',
        stock INT DEFAULT 0 COMMENT '库存',
        status TINYINT DEFAULT 1 COMMENT '状态: 1-上架 0-下架',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_category (category),
        INDEX idx_price (price),
        INDEX idx_sales (sales),
        FULLTEXT INDEX idx_search (name, description)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品表'
    `);
    logger.info('InitDB', '商品表创建成功');

    // 6. 创建购物车表
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS cart (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL COMMENT '用户ID',
        product_id INT NOT NULL COMMENT '商品ID',
        quantity INT NOT NULL DEFAULT 1 COMMENT '数量',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_user_id (user_id),
        UNIQUE KEY uk_user_product (user_id, product_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='购物车表'
    `);
    logger.info('InitDB', '购物车表创建成功');

    // 7. 创建订单表
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_no VARCHAR(32) NOT NULL UNIQUE COMMENT '订单编号',
        user_id INT NOT NULL COMMENT '用户ID',
        total_amount DECIMAL(10,2) NOT NULL COMMENT '订单总金额',
        status ENUM('pending', 'paid', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending' COMMENT '订单状态',
        receiver_name VARCHAR(50) DEFAULT '' COMMENT '收货人',
        receiver_phone VARCHAR(20) DEFAULT '' COMMENT '收货电话',
        receiver_address VARCHAR(500) DEFAULT '' COMMENT '收货地址',
        payment_method VARCHAR(20) DEFAULT 'online' COMMENT '支付方式',
        remark VARCHAR(500) DEFAULT '' COMMENT '备注',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_user_id (user_id),
        INDEX idx_order_no (order_no),
        INDEX idx_status (status),
        INDEX idx_created_at (created_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表'
    `);
    logger.info('InitDB', '订单表创建成功');

    // 8. 创建订单项表
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS order_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_id INT NOT NULL COMMENT '订单ID',
        product_id INT NOT NULL COMMENT '商品ID',
        product_name VARCHAR(200) NOT NULL COMMENT '商品名称（快照）',
        product_price DECIMAL(10,2) NOT NULL COMMENT '商品单价（快照）',
        quantity INT NOT NULL DEFAULT 1 COMMENT '购买数量',
        subtotal DECIMAL(10,2) NOT NULL COMMENT '小计',
        INDEX idx_order_id (order_id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单项表'
    `);
    logger.info('InitDB', '订单项表创建成功');

    // 9. 插入测试用户数据
    const salt = await bcrypt.genSalt(config.security.bcryptSaltRounds);
    const adminPassword = await bcrypt.hash('admin123', salt);
    const userPassword = await bcrypt.hash('123456', salt);

    const [existingUsers] = await connection.execute('SELECT COUNT(*) as count FROM users');
    if (existingUsers[0].count === 0) {
      await connection.execute(
        `INSERT INTO users (username, password, nickname, email, phone, role) VALUES
         ('admin', ?, '系统管理员', 'admin@shop.com', '13800000000', 'admin'),
         ('user1', ?, '张三', 'zhangsan@qq.com', '13800000001', 'user'),
         ('user2', ?, '李四', 'lisi@qq.com', '13800000002', 'user')`,
        [adminPassword, userPassword, userPassword]
      );
      logger.info('InitDB', '测试用户数据插入成功');
    } else {
      logger.info('InitDB', '用户数据已存在，跳过插入');
    }

    // 10. 插入测试商品数据
    const [existingProducts] = await connection.execute('SELECT COUNT(*) as count FROM products');
    if (existingProducts[0].count === 0) {
      await connection.execute(`
        INSERT INTO products (name, category, price, original_price, image_url, description, sales, stock) VALUES
        ('iPhone 15 Pro Max 256GB', '手机数码', 8999.00, 9999.00, '', 'Apple iPhone 15 Pro Max，256GB存储，钛金属设计，A17 Pro芯片', 1520, 100),
        ('MacBook Pro 14英寸 M3', '电脑办公', 14999.00, 16999.00, '', 'Apple MacBook Pro，M3芯片，14英寸Liquid Retina XDR显示屏', 890, 50),
        ('Sony WH-1000XM5 头戴式耳机', '影音娱乐', 2299.00, 2999.00, '', '索尼旗舰降噪耳机，30小时续航，Hi-Res音频', 2340, 200),
        ('Nike Air Jordan 1 复古篮球鞋', '运动户外', 1299.00, 1499.00, '', 'Nike经典复刻篮球鞋，Air Jordan 1 Retro High OG', 4560, 300),
        ('三只松鼠坚果大礼包 2kg', '食品生鲜', 99.00, 139.00, '', '混合坚果大礼包，含夏威夷果、腰果、巴旦木等', 8900, 500),
        ('华为MatePad Pro 13.2英寸', '手机数码', 4299.00, 4999.00, '', '华为旗舰平板，13.2英寸OLED屏幕，HarmonyOS系统', 670, 80),
        ('戴森V15 Detect 无绳吸尘器', '家用电器', 4990.00, 5490.00, '', '戴森无线吸尘器，激光探测微尘，LCD显示屏', 1230, 60),
        ('LEGO 乐高 兰博基尼 Sián FKP 37', '玩具乐器', 2999.00, 3499.00, '', '乐高机械组旗舰超跑，3696颗粒，1:8比例', 340, 30)
      `);
      logger.info('InitDB', '测试商品数据插入成功');
    } else {
      logger.info('InitDB', '商品数据已存在，跳过插入');
    }

    // 11. 插入测试订单数据
    const [existingOrders] = await connection.execute('SELECT COUNT(*) as count FROM orders');
    if (existingOrders[0].count === 0) {
      // 订单1：user1 的已支付订单
      await connection.execute(
        `INSERT INTO orders (order_no, user_id, total_amount, status, receiver_name, receiver_phone, receiver_address, payment_method)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        ['ORD20240325001', 2, 11298.00, 'paid', '张三', '13800000001', '广西南宁市西乡塘区大学东路188号 广西民族大学', 'online']
      );

      // 订单2：user1 的已发货订单
      await connection.execute(
        `INSERT INTO orders (order_no, user_id, total_amount, status, receiver_name, receiver_phone, receiver_address, payment_method)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        ['ORD20240324001', 2, 2299.00, 'shipped', '张三', '13800000001', '广西南宁市西乡塘区大学东路188号 广西民族大学', 'online']
      );

      // 订单3：user1 的已完成订单
      await connection.execute(
        `INSERT INTO orders (order_no, user_id, total_amount, status, receiver_name, receiver_phone, receiver_address, payment_method)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        ['ORD20240320001', 2, 99.00, 'delivered', '张三', '13800000001', '广西南宁市西乡塘区大学东路188号 广西民族大学', 'online']
      );

      // 订单4：user2 的待支付订单
      await connection.execute(
        `INSERT INTO orders (order_no, user_id, total_amount, status, receiver_name, receiver_phone, receiver_address, payment_method)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        ['ORD20240325002', 3, 14999.00, 'pending', '李四', '13800000002', '广西南宁市青秀区民族大道100号', 'online']
      );

      // 订单5：user2 的已取消订单
      await connection.execute(
        `INSERT INTO orders (order_no, user_id, total_amount, status, receiver_name, receiver_phone, receiver_address, payment_method)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        ['ORD20240323001', 3, 4299.00, 'cancelled', '李四', '13800000002', '广西南宁市青秀区民族大道100号', 'online']
      );

      // 插入订单项
      await connection.execute(`
        INSERT INTO order_items (order_id, product_id, product_name, product_price, quantity, subtotal) VALUES
        (1, 1, 'iPhone 15 Pro Max 256GB', 8999.00, 1, 8999.00),
        (1, 3, 'Sony WH-1000XM5 头戴式耳机', 2299.00, 1, 2299.00),
        (2, 3, 'Sony WH-1000XM5 头戴式耳机', 2299.00, 1, 2299.00),
        (3, 5, '三只松鼠坚果大礼包 2kg', 99.00, 1, 99.00),
        (4, 2, 'MacBook Pro 14英寸 M3', 14999.00, 1, 14999.00),
        (5, 6, '华为MatePad Pro 13.2英寸', 4299.00, 1, 4299.00)
      `);
      logger.info('InitDB', '测试订单数据插入成功');
    } else {
      logger.info('InitDB', '订单数据已存在，跳过插入');
    }

    console.log('\n========================================');
    console.log('  数据库初始化完成！');
    console.log('========================================');
    console.log('\n测试账号：');
    console.log('  管理员: admin / admin123');
    console.log('  用户1:  user1 / 123456');
    console.log('  用户2:  user2 / 123456');
    console.log('\n启动服务: npm run dev');
    console.log('========================================\n');

  } catch (error) {
    logger.error('InitDB', '数据库初始化失败', error);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

initDatabase();

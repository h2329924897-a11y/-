/**
 * 订单控制器 - 处理订单查询、详情等请求
 * 
 * ============================================================
 * 查询功能的前后端工作过程说明：
 * 
 * 1. 整体架构：
 *    [浏览器前端] <--HTTP--> [Express 后端] <--SQL--> [MySQL 数据库]
 * 
 * 2. 订单列表查询的完整工作流程：
 * 
 *    步骤①：前端发起请求
 *    - 用户在订单页面触发查询（页面加载 / 搜索 / 筛选 / 翻页）
 *    - 前端从 localStorage 读取 Token，设置到请求头 Authorization
 *    - 使用 Axios 发送 GET 请求到 /api/orders?page=1&pageSize=10
 *    
 *    步骤②：服务端接收请求
 *    - Express 路由匹配 GET /api/orders
 *    - authMiddleware 中间件拦截，提取并验证 JWT Token
 *    - Token 验证通过后，将用户信息注入 req.user
 *    - 路由转发到 orderController.list 方法
 *    
 *    步骤③：Controller 层处理业务逻辑
 *    - 从 req.query 提取分页参数（page, pageSize）
 *    - 从 req.query 提取筛选参数（status, keyword）
 *    - 校验参数合法性，设置默认值
 *    - 调用 Model 层的 findByUserId 方法
 *    
 *    步骤④：Model 层执行数据库查询
 *    - 构建参数化 SQL 查询语句（防 SQL 注入）
 *    - 执行 COUNT 查询获取总记录数
 *    - 执行联表查询：orders LEFT JOIN order_items LEFT JOIN products
 *    - 使用 GROUP BY 聚合每个订单的商品数量
 *    - 使用 LIMIT/OFFSET 实现分页
 *    
 *    步骤⑤：数据返回
 *    - Model 返回 { list, total, page, pageSize } 结构
 *    - Controller 包装为统一响应格式 { code, message, data }
 *    - Express 将数据序列化为 JSON 返回给前端
 *    
 *    步骤⑥：前端渲染
 *    - Axios 响应拦截器检查 code 是否为 200
 *    - 提取 data.list 渲染订单列表
 *    - 根据 data.total 计算分页信息
 *    - 用户可翻页、搜索、筛选，重复以上流程
 * 
 * 3. 关键设计点：
 *    - 参数化查询：所有 SQL 参数使用 ? 占位符，防止 SQL 注入
 *    - 分页查询：先 COUNT 再 SELECT，返回 total 供前端分页
 *    - 数据脱敏：不返回密码等敏感字段
 *    - 统一响应格式：{ code, message, data } 便于前端统一处理
 *    - 错误处理：try-catch 捕获异常，返回友好错误信息
 * ============================================================
 */

const OrderModel = require('../models/order');

const orderController = {
  /**
   * 查询用户订单列表
   * GET /api/orders?page=1&pageSize=10&status=&keyword=
   */
  list: async (req, res) => {
    try {
      const userId = req.user.userId;

      // 提取并校验查询参数
      const page = Math.max(1, parseInt(req.query.page) || 1);
      const pageSize = Math.min(50, Math.max(1, parseInt(req.query.pageSize) || 10));
      const status = req.query.status || null;
      const keyword = req.query.keyword || null;

      console.log(`[订单查询] 用户ID=${userId}, 页码=${page}, 每页=${pageSize}, 状态=${status}, 关键词=${keyword}`);

      // 调用 Model 层查询
      const result = await OrderModel.findByUserId(userId, {
        page,
        pageSize,
        status,
        keyword
      });

      // 统一响应格式
      res.json({
        code: 200,
        message: '查询成功',
        data: {
          list: result.list,
          pagination: {
            page: result.page,
            pageSize: result.pageSize,
            total: result.total,
            totalPages: Math.ceil(result.total / result.pageSize)
          }
        }
      });
    } catch (error) {
      console.error('[订单查询] 错误:', error);
      res.status(500).json({
        code: 500,
        message: '查询订单失败，请稍后重试'
      });
    }
  },

  /**
   * 查询订单详情
   * GET /api/orders/:id
   */
  detail: async (req, res) => {
    try {
      const userId = req.user.userId;
      const orderId = parseInt(req.params.id);

      if (isNaN(orderId)) {
        return res.status(400).json({
          code: 400,
          message: '订单ID格式不正确'
        });
      }

      const order = await OrderModel.findById(orderId, userId);

      if (!order) {
        return res.status(404).json({
          code: 404,
          message: '订单不存在或无权查看'
        });
      }

      res.json({
        code: 200,
        message: '查询成功',
        data: order
      });
    } catch (error) {
      console.error('[订单详情] 错误:', error);
      res.status(500).json({
        code: 500,
        message: '查询订单详情失败'
      });
    }
  },

  /**
   * 管理员查询所有订单
   * GET /api/admin/orders?page=1&pageSize=10&status=&keyword=
   */
  adminList: async (req, res) => {
    try {
      const page = Math.max(1, parseInt(req.query.page) || 1);
      const pageSize = Math.min(50, Math.max(1, parseInt(req.query.pageSize) || 10));
      const status = req.query.status || null;
      const keyword = req.query.keyword || null;

      const result = await OrderModel.findAll({
        page,
        pageSize,
        status,
        keyword
      });

      res.json({
        code: 200,
        message: '查询成功',
        data: {
          list: result.list,
          pagination: {
            page: result.page,
            pageSize: result.pageSize,
            total: result.total,
            totalPages: Math.ceil(result.total / result.pageSize)
          }
        }
      });
    } catch (error) {
      console.error('[管理员订单查询] 错误:', error);
      res.status(500).json({
        code: 500,
        message: '查询订单失败'
      });
    }
  }
};

module.exports = orderController;

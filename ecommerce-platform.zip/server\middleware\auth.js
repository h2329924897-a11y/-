/**
 * JWT 认证中间件
 * 
 * ============================================================
 * 登录验证原理说明：
 * 
 * 1. JWT (JSON Web Token) 是一种无状态的认证机制，由三部分组成：
 *    - Header（头部）：声明令牌类型和签名算法（如 HS256）
 *    - Payload（载荷）：包含用户标识（userId）、角色（role）、过期时间（exp）等
 *    - Signature（签名）：对 Header + Payload 使用密钥进行签名，防篡改
 * 
 * 2. 认证流程：
 *    [客户端]                    [服务端]
 *       |                           |
 *       |-- POST /api/auth/login -->|  ① 发送用户名和密码
 *       |                           |  ② 验证用户名密码
 *       |                           |  ③ 使用 bcrypt.compare 对比密码哈希
 *       |                           |  ④ 生成 JWT Token（包含 userId、role）
 *       |<-- { token, user } ------|  ⑤ 返回 Token 给客户端
 *       |                           |
 *       |-- GET /api/orders ------->|  ⑥ 请求携带 Token（Authorization: Bearer xxx）
 *       |   Authorization: Bearer   |  ⑦ 中间件拦截请求，提取 Token
 *       |                           |  ⑧ jwt.verify() 验证签名和有效期
 *       |                           |  ⑨ 解析出 userId，注入 req.user
 *       |                           |  ⑩ 业务逻辑处理
 *       |<-- 订单数据 -------------|  ⑪ 返回数据
 * 
 * 3. 安全性保障：
 *    - Token 使用服务器密钥签名，客户端无法伪造
 *    - bcrypt 哈希存储密码，即使数据库泄露密码也不可逆
 *    - Token 设置过期时间（默认24小时），降低泄露风险
 *    - 支持角色校验（普通用户/管理员），实现权限控制
 * ============================================================
 */

const jwt = require('jsonwebtoken');
const config = require('../config');
const logger = require('../utils/logger');

/**
 * Token 生成函数
 * @param {Object} payload - 要编码到 Token 中的数据
 * @param {string} expiresIn - 过期时间
 * @returns {string} JWT Token
 */
function generateToken(payload, expiresIn = config.jwt.expiresIn) {
  return jwt.sign(payload, config.jwt.secret, { expiresIn });
}

/**
 * Token 验证函数
 * @param {string} token - JWT Token 字符串
 * @returns {Object} 解码后的 payload
 */
function verifyToken(token) {
  return jwt.verify(token, config.jwt.secret);
}

/**
 * 认证中间件 - 验证请求是否携带有效 Token
 * 从请求头 Authorization: Bearer <token> 中提取并验证
 */
function authMiddleware(req, res, next) {
  // 从请求头获取 Authorization
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    return res.status(401).json({
      code: 401,
      message: '未提供认证令牌，请先登录'
    });
  }

  // 解析 Bearer Token
  const parts = authHeader.split(' ');
  if (parts.length !== 2 || parts[0] !== 'Bearer') {
    return res.status(401).json({
      code: 401,
      message: '认证令牌格式错误，应为 Bearer <token>'
    });
  }

  const token = parts[1];

  try {
    // 验证 Token 签名和有效期
    const decoded = verifyToken(token);
    // 将用户信息注入请求对象，后续路由可直接使用
    req.user = decoded;
    next();
  } catch (error) {
    logger.warn('Auth', `Token 验证失败: ${error.message}`);

    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        code: 401,
        message: '认证令牌已过期，请重新登录'
      });
    }
    return res.status(401).json({
      code: 401,
      message: '认证令牌无效'
    });
  }
}

/**
 * 可选认证中间件 - 有 Token 则解析，无 Token 也放行
 */
function optionalAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  if (authHeader) {
    const parts = authHeader.split(' ');
    if (parts.length === 2 && parts[0] === 'Bearer') {
      try {
        req.user = verifyToken(parts[1]);
      } catch (error) {
        // Token 无效也放行，只是不注入用户信息
      }
    }
  }
  next();
}

/**
 * 角色校验中间件工厂函数
 * @param  {...string} roles - 允许的角色列表
 * @returns {Function} Express 中间件
 */
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ code: 401, message: '请先登录' });
    }
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        code: 403,
        message: '权限不足，需要角色: ' + roles.join(', ')
      });
    }
    next();
  };
}

module.exports = {
  generateToken,
  verifyToken,
  authMiddleware,
  optionalAuth,
  requireRole
};

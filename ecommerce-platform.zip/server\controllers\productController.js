/**
 * 商品控制器
 */

const ProductModel = require('../models/product');

const productController = {
  /**
   * 商品列表
   * GET /api/products?page=1&pageSize=10&keyword=&category=&sortBy=price&sortOrder=ASC
   */
  list: async (req, res) => {
    try {
      const page = Math.max(1, parseInt(req.query.page) || 1);
      const pageSize = Math.min(50, Math.max(1, parseInt(req.query.pageSize) || 10));
      const { keyword, category, sortBy, sortOrder } = req.query;

      const result = await ProductModel.findAll({
        page,
        pageSize,
        keyword,
        category,
        sortBy,
        sortOrder
      });

      res.json({
        code: 200,
        message: '查询成功',
        data: {
          list: result.list,
          pagination: {
            page: result.page,
            pageSize: result.pageSize,
            total: result.total,
            totalPages: Math.ceil(result.total / result.pageSize)
          }
        }
      });
    } catch (error) {
      console.error('[商品列表] 错误:', error);
      res.status(500).json({
        code: 500,
        message: '查询商品失败'
      });
    }
  },

  /**
   * 商品详情
   * GET /api/products/:id
   */
  detail: async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      if (isNaN(productId)) {
        return res.status(400).json({ code: 400, message: '商品ID格式不正确' });
      }

      const product = await ProductModel.findById(productId);
      if (!product) {
        return res.status(404).json({ code: 404, message: '商品不存在' });
      }

      res.json({
        code: 200,
        message: '查询成功',
        data: product
      });
    } catch (error) {
      console.error('[商品详情] 错误:', error);
      res.status(500).json({ code: 500, message: '查询商品详情失败' });
    }
  }
};

module.exports = productController;

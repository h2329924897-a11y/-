/**
 * 统一响应格式工具
 * 所有 API 响应遵循 { code, message, data } 格式
 */

/**
 * 成功响应
 * @param {Response} res - Express response 对象
 * @param {*} data - 响应数据
 * @param {string} message - 提示信息
 * @param {number} statusCode - HTTP 状态码
 */
function success(res, data = null, message = '操作成功', statusCode = 200) {
  return res.status(statusCode).json({
    code: statusCode,
    message,
    data
  });
}

/**
 * 失败响应
 * @param {Response} res - Express response 对象
 * @param {string} message - 错误信息
 * @param {number} statusCode - HTTP 状态码
 * @param {*} data - 额外错误数据
 */
function fail(res, message = '操作失败', statusCode = 400, data = null) {
  return res.status(statusCode).json({
    code: statusCode,
    message,
    data
  });
}

/**
 * 分页响应
 * @param {Response} res - Express response 对象
 * @param {Array} list - 数据列表
 * @param {Object} pagination - 分页信息 { page, pageSize, total }
 * @param {string} message - 提示信息
 */
function paginated(res, list, pagination, message = '查询成功') {
  const { page, pageSize, total } = pagination;
  return res.status(200).json({
    code: 200,
    message,
    data: {
      list,
      pagination: {
        page,
        pageSize,
        total,
        totalPages: Math.ceil(total / pageSize)
      }
    }
  });
}

module.exports = { success, fail, paginated };

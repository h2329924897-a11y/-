/**
 * 电商购物平台 - 后端服务入口
 * 
 * 架构说明：
 * - Express 框架提供 RESTful API
 * - JWT 实现无状态用户认证
 * - MySQL 存储业务数据
 * - 分层架构：Routes → Controllers → Models → Database
 * 
 * 工程化特性：
 * - 统一配置管理 (config/index.js)
 * - 分级日志记录 (utils/logger.js)
 * - 统一响应格式 (utils/response.js)
 * - 请求参数验证 (middleware/validator.js)
 * - 速率限制防护 (middleware/rateLimiter.js)
 * - 安全头设置 (helmet)
 * - Gzip 压缩 (compression)
 */
require('dotenv').config();

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const path = require('path');

const config = require('./config');
const logger = require('./utils/logger');
const AppError = require('./utils/AppError');
const { apiLimiter } = require('./middleware/rateLimiter');

// 导入路由模块
const authRoutes = require('./routes/auth');
const orderRoutes = require('./routes/orders');
const productRoutes = require('./routes/products');

// 导入数据库模块
const { testConnection } = require('./config/db');

const app = express();

// ==================== 安全与性能中间件 ====================

// Helmet 安全头
app.use(helmet({
  contentSecurityPolicy: false, // 允许加载 CDN 脚本
  crossOriginEmbedderPolicy: false
}));

// Gzip 压缩
app.use(compression());

// CORS 跨域配置
app.use(cors(config.cors));

// 通用 API 速率限制
app.use('/api', apiLimiter);

// JSON 请求体解析（限制大小防止大 payload 攻击）
app.use(express.json({ limit: '1mb' }));

// URL 编码请求体解析
app.use(express.urlencoded({ extended: true, limit: '1mb' }));

// 静态文件服务（前端页面）
app.use(express.static(path.join(__dirname, '..', 'frontend')));

// 请求日志中间件
app.use((req, res, next) => {
  const start = Date.now();
  const { method, url } = req;

  res.on('finish', () => {
    const duration = Date.now() - start;
    const { statusCode } = res;
    logger.info('HTTP', `${method} ${url} ${statusCode} ${duration}ms`);
  });

  next();
});

// ==================== 路由注册 ====================

// 认证路由（登录接口有独立的限流器）
app.use('/api/auth', authRoutes);

// 订单路由（需认证）
app.use('/api/orders', orderRoutes);

// 商品路由（可选认证）
app.use('/api/products', productRoutes);

// ==================== 全局错误处理 ====================

// 404 处理
app.use((req, res) => {
  res.status(404).json({
    code: 404,
    message: `接口 ${req.method} ${req.url} 不存在`
  });
});

// 全局错误处理中间件
app.use((err, req, res, next) => {
  // 记录完整错误日志
  logger.error('Server', err.message, err);

  // 区分操作错误和程序错误
  if (err instanceof AppError) {
    return res.status(err.statusCode).json({
      code: err.code,
      message: err.message
    });
  }

  // 未知错误
  res.status(500).json({
    code: 500,
    message: '服务器内部错误',
    error: config.server.isDev ? err.message : undefined
  });
});

// ==================== 启动服务 ====================

async function startServer() {
  // 测试数据库连接
  const dbConnected = await testConnection();

  if (!dbConnected) {
    logger.warn('Server', '数据库连接失败，请先运行 npm run init-db 初始化数据库');
    logger.warn('Server', '服务将以无数据库模式启动（部分功能不可用）');
  }

  app.listen(config.server.port, () => {
    console.log('========================================');
    console.log(`  电商购物平台服务已启动`);
    console.log(`  地址: http://localhost:${config.server.port}`);
    console.log(`  环境: ${config.server.env}`);
    console.log('========================================');
    console.log('\nAPI 接口列表:');
    console.log('  POST /api/auth/login       - 用户登录');
    console.log('  GET  /api/auth/me           - 当前用户信息');
    console.log('  GET  /api/orders            - 订单列表');
    console.log('  GET  /api/orders/:id        - 订单详情');
    console.log('  GET  /api/products          - 商品列表');
    console.log('  GET  /api/products/:id      - 商品详情');
    console.log('\n前端页面:');
    console.log(`  http://localhost:${config.server.port}/index.html   - 登录页面`);
    console.log(`  http://localhost:${config.server.port}/orders.html  - 订单页面`);
    console.log('========================================\n');
  });
}

startServer();

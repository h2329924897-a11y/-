/**
 * 用户模型 - 数据访问层
 * 封装用户相关的数据库操作
 */

const db = require('../config/db');

const UserModel = {
  /**
   * 根据用户名查找用户
   * @param {string} username
   * @returns {Promise<Object|null>}
   */
  findByUsername: async (username) => {
    return db.queryOne(
      'SELECT id, username, password, nickname, email, phone, role, status, created_at FROM users WHERE username = ?',
      [username]
    );
  },

  /**
   * 根据用户ID查找用户
   * @param {number} id
   * @returns {Promise<Object|null>}
   */
  findById: async (id) => {
    return db.queryOne(
      'SELECT id, username, nickname, email, phone, role, status, created_at FROM users WHERE id = ?',
      [id]
    );
  },

  /**
   * 创建新用户
   * @param {Object} userData
   * @returns {Promise<Object>}
   */
  create: async (userData) => {
    const result = await db.query(
      `INSERT INTO users (username, password, nickname, email, phone, role) 
       VALUES (?, ?, ?, ?, ?, ?)`,
      [userData.username, userData.password, userData.nickname, userData.email, userData.phone, userData.role || 'user']
    );
    return { id: result.insertId, ...userData };
  }
};

module.exports = UserModel;

# 电商购物平台 - 网络编程实验项目

> 广西民族大学 · 网络编程实验  
> 技术栈：Node.js + Express + JWT + MySQL + HTML/CSS/JavaScript

## 功能模块

### 已完成 ✅
- **登录验证模块**：JWT Token 认证、bcrypt 密码哈希、角色权限控制
- **订单查询模块**：订单列表（分页+搜索+筛选）、订单详情、管理员全量查询
- **商品查询模块**：商品列表（分页+搜索+排序）、商品详情
- **工程化优化**：统一配置管理、分级日志、参数校验、速率限制、安全头防护

### 数据库设计
- `users` - 用户表（username, password, role, status）
- `products` - 商品表（name, category, price, stock）
- `orders` - 订单表（order_no, user_id, status, total_amount）
- `order_items` - 订单项表（order_id, product_id, quantity, subtotal）
- `cart` - 购物车表（user_id, product_id, quantity）

## 快速开始

```bash
# 1. 安装依赖
npm install

# 2. 配置 .env 文件中的数据库连接信息

# 3. 初始化数据库（创建表 + 插入测试数据）
npm run init-db

# 4. 启动服务
npm run dev
```

浏览器访问：
- 登录页面：http://localhost:3000/index.html
- 订单页面：http://localhost:3000/orders.html

## 测试账号

| 角色 | 用户名 | 密码 |
|------|--------|------|
| 管理员 | admin | admin123 |
| 用户1 | user1 | 123456 |
| 用户2 | user2 | 123456 |

## API 接口

| 方法 | 路径 | 说明 | 认证 |
|------|------|------|------|
| POST | /api/auth/login | 用户登录 | 否 |
| GET | /api/auth/me | 当前用户信息 | 是 |
| GET | /api/orders | 订单列表 | 是 |
| GET | /api/orders/:id | 订单详情 | 是 |
| GET | /api/admin/orders/list | 管理员查所有订单 | 是(admin) |
| GET | /api/products | 商品列表 | 否 |
| GET | /api/products/:id | 商品详情 | 否 |

## 原理说明

详见 [docs/原理说明.md](docs/原理说明.md)

/**
 * 认证路由
 */
const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { authMiddleware } = require('../middleware/auth');
const { loginValidation } = require('../middleware/validator');
const { loginLimiter } = require('../middleware/rateLimiter');

// POST /api/auth/login - 用户登录（无需认证，但有登录限流和参数校验）
router.post('/login', loginLimiter, loginValidation, authController.login);

// GET /api/auth/me - 获取当前用户信息（需认证）
router.get('/me', authMiddleware, authController.getCurrentUser);

module.exports = router;

/**
 * 应用配置中心
 * 统一管理所有配置项，支持环境变量覆盖
 */

const config = {
  // 服务器配置
  server: {
    port: parseInt(process.env.PORT, 10) || 3000,
    env: process.env.NODE_ENV || 'development',
    isDev: (process.env.NODE_ENV || 'development') === 'development',
    isProd: process.env.NODE_ENV === 'production'
  },

  // 数据库配置
  db: {
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT, 10) || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'ecommerce_platform',
    connectionLimit: 10,
    charset: 'utf8mb4'
  },

  // JWT 配置
  jwt: {
    secret: process.env.JWT_SECRET || 'ecommerce_jwt_secret_key_2024',
    expiresIn: process.env.JWT_EXPIRES_IN || '24h'
  },

  // 安全配置
  security: {
    // bcrypt 加密轮次
    bcryptSaltRounds: 10,
    // 登录接口限流：15分钟内最多10次
    loginRateLimit: {
      windowMs: 15 * 60 * 1000,
      max: 10,
      message: '登录尝试过于频繁，请15分钟后再试'
    },
    // 通用 API 限流：每分钟最多100次
    apiRateLimit: {
      windowMs: 60 * 1000,
      max: 100,
      message: '请求过于频繁，请稍后再试'
    }
  },

  // CORS 配置
  cors: {
    origin: process.env.CORS_ORIGIN || '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
  }
};

module.exports = config;

/**
 * 认证控制器 - 处理用户登录、注册、获取当前用户等请求
 */

const bcrypt = require('bcryptjs');
const UserModel = require('../models/user');
const { generateToken } = require('../middleware/auth');

const authController = {
  /**
   * 用户登录
   * POST /api/auth/login
   * Body: { username, password }
   */
  login: async (req, res) => {
    try {
      const { username, password } = req.body;

      // 参数校验
      if (!username || !password) {
        return res.status(400).json({
          code: 400,
          message: '用户名和密码不能为空'
        });
      }

      // 查找用户
      const user = await UserModel.findByUsername(username);
      if (!user) {
        return res.status(401).json({
          code: 401,
          message: '用户名或密码错误'
        });
      }

      // 检查用户状态
      if (user.status === 0) {
        return res.status(403).json({
          code: 403,
          message: '账户已被禁用，请联系管理员'
        });
      }

      // 验证密码（bcrypt 哈希比对）
      const isPasswordValid = await bcrypt.compare(password, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({
          code: 401,
          message: '用户名或密码错误'
        });
      }

      // 生成 JWT Token
      const tokenPayload = {
        userId: user.id,
        username: user.username,
        role: user.role
      };
      const token = generateToken(tokenPayload, '24h');

      // 返回用户信息和 Token
      const userInfo = {
        id: user.id,
        username: user.username,
        nickname: user.nickname,
        email: user.email,
        phone: user.phone,
        role: user.role
      };

      console.log(`[登录] 用户 ${username} 登录成功`);

      res.json({
        code: 200,
        message: '登录成功',
        data: {
          token,
          user: userInfo
        }
      });
    } catch (error) {
      console.error('[登录] 错误:', error);
      res.status(500).json({
        code: 500,
        message: '服务器内部错误'
      });
    }
  },

  /**
   * 获取当前登录用户信息
   * GET /api/auth/me
   * Header: Authorization: Bearer <token>
   */
  getCurrentUser: async (req, res) => {
    try {
      const user = await UserModel.findById(req.user.userId);
      if (!user) {
        return res.status(404).json({
          code: 404,
          message: '用户不存在'
        });
      }

      res.json({
        code: 200,
        data: user
      });
    } catch (error) {
      console.error('[获取用户信息] 错误:', error);
      res.status(500).json({
        code: 500,
        message: '服务器内部错误'
      });
    }
  }
};

module.exports = authController;

/**
 * 请求参数验证中间件
 * 基于 express-validator 进行输入校验
 */
const { validationResult, body, query, param } = require('express-validator');

/**
 * 验证结果处理中间件
 * 检查 express-validator 的验证结果，有错误则返回 400
 */
function handleValidationErrors(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const firstError = errors.array()[0];
    return res.status(400).json({
      code: 400,
      message: `参数验证失败: ${firstError.msg}`,
      errors: process.env.NODE_ENV === 'development' ? errors.array() : undefined
    });
  }
  next();
}

/**
 * 登录请求验证规则
 */
const loginValidation = [
  body('username')
    .trim()
    .notEmpty().withMessage('用户名不能为空')
    .isLength({ min: 2, max: 50 }).withMessage('用户名长度为2-50个字符')
    .matches(/^[a-zA-Z0-9_]+$/).withMessage('用户名只能包含字母、数字和下划线'),
  body('password')
    .notEmpty().withMessage('密码不能为空')
    .isLength({ min: 4, max: 30 }).withMessage('密码长度为4-30个字符'),
  handleValidationErrors
];

/**
 * 分页参数验证规则
 */
const paginationValidation = [
  query('page')
    .optional()
    .isInt({ min: 1 }).withMessage('页码必须为正整数'),
  query('pageSize')
    .optional()
    .isInt({ min: 1, max: 50 }).withMessage('每页条数范围为1-50'),
  handleValidationErrors
];

/**
 * ID 参数验证规则
 */
const idValidation = [
  param('id')
    .isInt({ min: 1 }).withMessage('ID必须为正整数'),
  handleValidationErrors
];

module.exports = {
  handleValidationErrors,
  loginValidation,
  paginationValidation,
  idValidation
};

/**
 * 速率限制中间件
 * 防止暴力破解和 DDoS 攻击
 */
const rateLimit = require('express-rate-limit');
const config = require('../config');

/**
 * 登录接口限流器
 * 15分钟内最多允许10次登录尝试（同一IP）
 */
const loginLimiter = rateLimit({
  windowMs: config.security.loginRateLimit.windowMs,
  max: config.security.loginRateLimit.max,
  message: {
    code: 429,
    message: config.security.loginRateLimit.message
  },
  standardHeaders: true,
  legacyHeaders: false,
  skipSuccessfulRequests: false // 成功登录也计入次数
});

/**
 * 通用 API 限流器
 * 每分钟最多100次请求（同一IP）
 */
const apiLimiter = rateLimit({
  windowMs: config.security.apiRateLimit.windowMs,
  max: config.security.apiRateLimit.max,
  message: {
    code: 429,
    message: config.security.apiRateLimit.message
  },
  standardHeaders: true,
  legacyHeaders: false
});

module.exports = { loginLimiter, apiLimiter };

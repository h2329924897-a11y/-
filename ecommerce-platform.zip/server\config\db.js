/**
 * 数据库配置模块
 * 使用 MySQL 连接池管理数据库连接
 */
const mysql = require('mysql2/promise');
const config = require('./index');
const logger = require('../utils/logger');

// 数据库连接池配置
const pool = mysql.createPool({
  host: config.db.host,
  port: config.db.port,
  user: config.db.user,
  password: config.db.password,
  database: config.db.database,
  waitForConnections: true,
  connectionLimit: config.db.connectionLimit,
  queueLimit: 0,
  charset: config.db.charset
});

/**
 * 测试数据库连接
 * @returns {Promise<boolean>}
 */
async function testConnection() {
  try {
    const connection = await pool.getConnection();
    logger.info('DB', 'MySQL 连接成功');
    connection.release();
    return true;
  } catch (error) {
    logger.error('DB', 'MySQL 连接失败', error);
    return false;
  }
}

/**
 * 执行 SQL 查询（参数化，防 SQL 注入）
 * @param {string} sql - SQL 语句
 * @param {Array} params - 参数数组
 * @returns {Promise<Array>} 查询结果
 */
async function query(sql, params = []) {
  try {
    const [rows] = await pool.execute(sql, params);
    return rows;
  } catch (error) {
    logger.error('DB', `SQL 查询失败: ${sql.substring(0, 100)}`, error);
    throw error;
  }
}

/**
 * 执行单条查询（返回第一条记录）
 * @param {string} sql - SQL 语句
 * @param {Array} params - 参数数组
 * @returns {Promise<Object|null>}
 */
async function queryOne(sql, params = []) {
  const rows = await query(sql, params);
  return rows.length > 0 ? rows[0] : null;
}

module.exports = {
  pool,
  query,
  queryOne,
  testConnection
};

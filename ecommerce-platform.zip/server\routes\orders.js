/**
 * 订单路由
 */
const express = require('express');
const router = express.Router();
const orderController = require('../controllers/orderController');
const { authMiddleware, requireRole } = require('../middleware/auth');
const { paginationValidation, idValidation } = require('../middleware/validator');

// GET /api/orders - 查询用户订单列表（需认证 + 分页参数校验）
router.get('/', authMiddleware, paginationValidation, orderController.list);

// GET /api/orders/:id - 查询订单详情（需认证 + ID参数校验）
router.get('/:id', authMiddleware, idValidation, orderController.detail);

// GET /api/admin/orders - 管理员查询所有订单（需认证 + 管理员角色 + 分页校验）
router.get('/admin/list', authMiddleware, requireRole('admin'), paginationValidation, orderController.adminList);

module.exports = router;
